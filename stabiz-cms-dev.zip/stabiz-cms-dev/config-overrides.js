const path = require("path");
const {
  override,
  fixBabelImports,
  addLessLoader,
  addWebpackAlias,
  addPostcssPlugins,
} = require("customize-cra");
const { getThemeVariables } = require("antd/dist/theme");

const aliases = (prefix = `src`) => ({
  "@shared": `${prefix}/shared/`,
  "@assets": `${prefix}/assets/`,
  "@": `${prefix}/`,
});

const resolvedAliases = Object.fromEntries(
  Object.entries(aliases()).map(([key, value]) => [
    key,
    path.resolve(__dirname, value),
  ])
);

module.exports = override(
  fixBabelImports("import", {
    libraryName: "antd",
    libraryDirectory: "es",
    style: true,
  }),
  addLessLoader({
    lessOptions: {
      javascriptEnabled: true,
      modifyVars: {
        ...getThemeVariables({
          // dark: true, // Enable dark mode
          // compact: true, // Enable compact mode
          // "@border-radius-base": "44px",
        }),
        "@primary-color": "#1DA57A",
        "@border-radius-base": "4px",
        "@font-size-base": "14px",
        // "@animation-duration-slow": "0s", // Modal
        // "@animation-duration-base": "0s",
        // "@animation-duration-fast": "0s",
      },
    },
  }),
  addWebpackAlias({ ...resolvedAliases }),
  addPostcssPlugins([require("tailwindcss"), require("autoprefixer")])
);
