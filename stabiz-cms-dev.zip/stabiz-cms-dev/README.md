# Stabiz CMS

[ ] Write the docs for base structure

