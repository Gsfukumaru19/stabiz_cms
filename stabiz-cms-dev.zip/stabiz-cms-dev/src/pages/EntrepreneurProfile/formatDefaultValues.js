// eslint-disable-next-line import/prefer-default-export
export const formatUserFormDefaultValues = (userObj) => {
  const tempUser = { ...userObj };

  delete tempUser?.entrepreneur_profile;

  const formattedValues = userObj?.entrepreneur_profile;

  return {
    ...formattedValues,
    ...tempUser,
    area_id: formattedValues.area?.id,
    prefecture_id: formattedValues.prefecture?.id,
    education_background_id: formattedValues.education_background?.id,
    expected_income_range_id: formattedValues.expected_income?.id,
    management_exp_id: formattedValues.management_exp?.id,
    en_lang_level_id: formattedValues.en_lang_ability?.id,
    occupation_id: formattedValues.occupation?.id,
    present_post_id: formattedValues.present_post?.id,
    working_status_id: formattedValues.working_status?.id,
    industry_ids: formattedValues.industries_exp?.map((i) => i.id),
    pfd_industry_ids: formattedValues.industries_pfd?.map((i) => i.id),
    pfd_position_ids: formattedValues.positions_pfd?.map((i) => i.id),
    pfd_prefecture_ids: formattedValues.prefectures_pfd?.map((i) => i.id),
    dob: new Date(userObj.dob),
    work_start_date: formattedValues.work_start_date
      ? new Date(formattedValues.work_start_date)
      : null,
  };
};
