import { handleQuery } from "@shared/services/api-client";

/* ---- VALUES ---- */
export const fetchPrefectures = async (queryParams) =>
  handleQuery({
    resourceUrl: `/prefecture`,
    queryParams,
  });

export const fetchIncomeValues = async () =>
  handleQuery({
    resourceUrl: `/income`,
  });

export const fetchAreas = async () =>
  handleQuery({
    resourceUrl: `/area`,
  });

export const fetchEducationBackgrounds = async () =>
  handleQuery({
    resourceUrl: `/education-backgrounds`,
  });

export const fetchWorkingStatuses = async () =>
  handleQuery({
    resourceUrl: `/working-status`,
  });

export const fetchLangLevels = async () =>
  handleQuery({
    resourceUrl: `/lang-level`,
  });

export const fetchOccupations = async () =>
  handleQuery({
    resourceUrl: `/occupation`,
  });

export const fetchPreferredJobTitles = async () =>
  handleQuery({
    resourceUrl: `/preferred-job-title`,
  });

export const fetchPresentPosts = async () =>
  handleQuery({
    resourceUrl: `/present-post`,
  });

export const fetchLangs = async () =>
  handleQuery({
    resourceUrl: `/lang`,
  });

export const fetchIndustries = async () =>
  handleQuery({
    resourceUrl: `/industry`,
  });

export const fetchIndustryCategories = async () =>
  handleQuery({
    resourceUrl: `/industry-categories`,
  });

export const fetchPositions = async () =>
  handleQuery({
    resourceUrl: `/position`,
  });

export const fetchManagementExperiences = async () =>
  handleQuery({
    resourceUrl: `/mgmt-exp`,
  });
