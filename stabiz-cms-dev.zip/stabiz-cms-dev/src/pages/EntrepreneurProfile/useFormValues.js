import { useQuery } from "react-query";

import {
  fetchAreas,
  fetchEducationBackgrounds,
  fetchIncomeValues,
  fetchIndustries,
  fetchLangLevels,
  fetchManagementExperiences,
  fetchOccupations,
  fetchPositions,
  fetchPrefectures,
  fetchPresentPosts,
  fetchWorkingStatuses,
} from "./queries";

export const useAreas = () => useQuery("areas", () => fetchAreas());
export const useIndustries = () =>
  useQuery("industries", () => fetchIndustries());
export const usePositions = () => useQuery("positions", () => fetchPositions());
export const useAllPrefectures = () =>
  useQuery("allPrefectures", () => fetchPrefectures());
export const useIncomes = () =>
  useQuery("incomeValues", () => fetchIncomeValues());
export const useWorkingStatuses = () =>
  useQuery("workingStatuses", () => fetchWorkingStatuses());
export const usePresentPosts = () =>
  useQuery("presentPosts", () => fetchPresentPosts());
export const useOccupations = () =>
  useQuery("occupations", () => fetchOccupations());
export const useLangLevels = () =>
  useQuery("langLevels", () => fetchLangLevels());
export const useManagementExperiences = () =>
  useQuery("managementExperiences", () => fetchManagementExperiences());
export const useEduBackgrounds = () =>
  useQuery("eduBackgrounds", () => fetchEducationBackgrounds());
