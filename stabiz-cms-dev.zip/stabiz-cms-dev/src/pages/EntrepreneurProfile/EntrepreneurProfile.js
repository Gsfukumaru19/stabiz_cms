import { fetchDiagnosisUser, fetchUser } from "@shared/services";
import { Col, Row } from "antd";
import { useQuery } from "react-query";
import { useParams } from "react-router-dom";

import DetailsContainer from "./components/DetailsContainer";
import LeftContainer from "./components/LeftContainer";

export default function EntrepreneurProfile() {
  const { userId } = useParams();

  const entrepreneurResult = useQuery("entrepreneur", () => fetchUser(userId), {
    cacheTime: 0,
  });
  const diagnosisUserResult = useQuery("diagnosisUser", () =>
    fetchDiagnosisUser({ userId })
  );
  return (
    <div>
      <Row gutter={0}>
        <Col span={8}>
          <LeftContainer userDetails={entrepreneurResult?.data?.data || {}} />
        </Col>
        <Col span={16}>
          {entrepreneurResult?.data?.data && (
            <DetailsContainer
              userDetails={entrepreneurResult?.data?.data}
              refetchEditedUser={entrepreneurResult.refetch}
            />
          )}
        </Col>
      </Row>
    </div>
  );
}
