/* eslint-disable no-irregular-whitespace */
import * as yup from "yup";

// eslint-disable-next-line import/prefer-default-export
export const editDetailsSchema = yup.object().shape({
  last_name: yup.string().required("Required").nullable(),
  last_name_cana: yup
    .string()
    .required("Required")
    .nullable()
    .matches(/^[ぁ-んー　]*$/, {
      message: "名（ふりがな）はひらがなで入力してください。",
    }),
  first_name: yup.string().required("Required").nullable(),
  first_name_cana: yup
    .string()
    .required("Required")
    .nullable()
    .matches(/^[ぁ-んー　]*$/, {
      message: "名（ふりがな）はひらがなで入力してください。",
    }),
  address: yup.string().required("Required").nullable(),
  school_name: yup.string().required("Required").nullable(),
  present_company: yup.string().required("Required").nullable(),
  dob: yup.string().required("Required").nullable(),
  area_id: yup.mixed().required("Required").nullable(),
  education_background_id: yup.mixed().required("Required").nullable(),
  en_lang_level_id: yup.mixed().required("Required").nullable(),
  expected_income_range_id: yup.mixed().required("Required").nullable(),
  gender: yup.mixed().required("Required").nullable(),
  // lang_level_id: yup.mixed().required("Required").nullable(),
  occupation_id: yup.mixed().required("Required").nullable(),
  prefecture_id: yup.mixed().required("Required").nullable(),
  present_post_id: yup.mixed().required("Required").nullable(),
  present_post_other: yup
    .string()
    .when("present_post_id", {
      is: "other",
      then: yup.string().required("Required").nullable(),
    })
    .nullable(),
  transfer: yup.mixed().required("Required").nullable(),
  working_status_id: yup.mixed().required("Required").nullable(),
  management_exp_id: yup.mixed().required("Required").nullable(),
  industry_ids: yup.mixed().required("Required").nullable(),
  pfd_industry_ids: yup.mixed().required("Required").nullable(),
  pfd_position_ids: yup.mixed().required("Required").nullable(),
  pfd_prefecture_ids: yup.mixed().required("Required").nullable(),
  income_range_id: yup.mixed().required("Required").nullable(),
  work_start_date: yup.string().required("Required").nullable(),
  school_major: yup.string().required("Required").nullable(),
});
