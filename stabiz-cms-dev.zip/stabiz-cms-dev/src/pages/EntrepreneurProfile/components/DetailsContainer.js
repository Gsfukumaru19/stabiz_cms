import { RadarChartOutlined, UserOutlined } from "@ant-design/icons";
import { Layout, Tabs } from "antd";
import { useTranslation } from "react-i18next";
import { ResultCharts, SalesChart } from "shared/components";

import RecommendTab from "./RecommendTab";
import UserDetails from "./UserDetails";

const { TabPane } = Tabs;

export default function DetailsContainer({ userDetails, refetchEditedUser }) {
  const { t } = useTranslation();

  // const diagnosisUserResult = useQuery(
  //   "diagnosisUser",
  //   () => fetchDiagnosisUser({ userId: userDetails.id }),
  //   {
  //     retry: true,
  //   }
  // );

  return (
    <Layout
      style={{
        minHeight: "108%",
        marginTop: "-32px",
        marginBottom: "-24px",
      }}
    >
      <Layout.Content
        style={{
          margin: "1.5rem 1rem",
          padding: 24,
          background: "#fff",
          minHeight: "280px",
          borderRadius: "4px",
        }}
      >
        <div>
          <Tabs>
            <TabPane
              tab={
                <span>
                  <UserOutlined />
                  {t("User Details")}
                </span>
              }
              key="1"
            >
              <UserDetails
                userDetailsData={userDetails}
                refetchEditedUser={refetchEditedUser}
              />
            </TabPane>
            <TabPane
              tab={
                <span>
                  <RadarChartOutlined />
                  {t("Results")}
                </span>
              }
              key="2"
            >
              {/* {diagnosisUserResult?.data?.current_section == "0" ? ( */}
              <ResultCharts userDetails={userDetails} />
              {/* ) : (
                <h3>{t("no result data")}</h3>
              )} */}
            </TabPane>
            <TabPane
              tab={
                <span>
                  <RadarChartOutlined />
                  {t("recommend user")}
                </span>
              }
              key="3"
            >
              <RecommendTab userDetails={userDetails} />
            </TabPane>
          </Tabs>
        </div>
      </Layout.Content>
    </Layout>
  );
}

function UserSales() {
  return (
    <div>
      <p className="mb-32">User sale statistics</p>
      <SalesChart />
    </div>
  );
}
