import { Button, Divider } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { ProfileDetail } from "shared/components/Profile";
import { formatIncomeRange } from "shared/utils";

import { EditDetails } from "./EditDetails";

export default function UserDetails({ userDetailsData, refetchEditedUser }) {
  const [currentMode, setCurrentMode] = useState("view");
  const userDetails = {
    ...userDetailsData,
    ...userDetailsData?.entrepreneur_profile,
  };

  return (
    <div>
      {currentMode === "view" ? (
        <Details data={userDetails} onModeChange={setCurrentMode} />
      ) : (
        <EditDetails
          currentMode={currentMode}
          onModeChange={setCurrentMode}
          userDetailsData={userDetails}
          refetchEditedUser={refetchEditedUser}
        />
      )}
    </div>
  );
}

function Details({ data, onModeChange }) {
  const { t } = useTranslation();
  return (
    <div>
      <div className="flex">
        <Button
          type="primary"
          style={{ marginLeft: "auto" }}
          onClick={() => {
            onModeChange("edit");
          }}
        >
          {t("Edit")}
        </Button>
      </div>

      {/* ADDRESS */}
      <div className="flex flex-col" style={{ marginTop: "2rem" }}>
        <ProfileDetail heading="last_name" data={data.last_name} />
        <ProfileDetail heading="first_name" data={data.first_name} />
        <ProfileDetail heading="last_name_cana" data={data.last_name_cana} />
        <ProfileDetail heading="first_name_cana" data={data.first_name_cana} />
        <ProfileDetail heading="gender" data={t(data.gender)} />
        <ProfileDetail heading="dob" data={data.dob} />

        <ProfileDetail heading="area" data={data?.area?.name} />
        <ProfileDetail heading="prefecture" data={data?.prefecture?.name} />
        <ProfileDetail heading="address" data={data.address} />
        <ProfileDetail
          heading="income"
          data={formatIncomeRange(data?.income)}
        />
      </div>

      {/* EDUCATION */}
      <Divider orientation="left" style={{ marginTop: "2rem" }}>
        {t("Education")}
      </Divider>
      <div className="flex flex-col">
        <ProfileDetail
          heading="education_background"
          data={data?.education_background?.label}
        />
        <ProfileDetail heading="school_name" data={data?.school_name} />
        {/* TODO */}
        <ProfileDetail heading="school_major" data={data?.school_major} />
      </div>

      {/* PROFESSIONAL */}
      <Divider orientation="left" style={{ marginTop: "2rem" }}>
        {t("work")}
      </Divider>
      <ProfileDetail
        heading="Working Status"
        data={data?.working_status?.label}
      />
      <ProfileDetail heading="Present Company" data={data?.present_company} />
      <ProfileDetail heading="Present Post" data={data?.present_post?.name} />
      <ProfileDetail heading="Occupation" data={data?.occupation?.name} />
      <ProfileDetail
        heading="Industry"
        data={data?.industries_exp?.map((i) => i?.name).join(", ")}
      />
      <ProfileDetail heading="Transfer" data={data?.transfer} />
      <ProfileDetail
        heading="english_language_level"
        data={data?.en_lang_ability?.level}
      />
      <ProfileDetail
        heading="has_management_experience"
        data={data?.management_exp?.exp}
      />

      <Divider orientation="left" style={{ marginTop: "2rem" }}>
        {t("preference")}
      </Divider>
      <div className="flex flex-col">
        <ProfileDetail
          heading="Preferred Positions"
          data={data?.positions_pfd?.map((d) => d?.name).join(", ")}
        />
        {/* <Detail
              heading={t("prefered_industries")}
              data={industries_pfd?.map((i) => i?.name).join(",")}
            /> */}
        <ProfileDetail
          heading="Preferred Industries"
          data={data?.industries_pfd?.map((d) => d.name).join(", ")}
        />
        <ProfileDetail
          heading="Preferred Prefectures"
          data={data?.prefectures_pfd?.map((d) => d.name).join(", ")}
        />
        <ProfileDetail
          heading="Expected Income range"
          data={formatIncomeRange(data?.expected_income)}
        />
        <ProfileDetail heading="Work start date" data={data?.work_start_date} />
      </div>
    </div>
  );
}
