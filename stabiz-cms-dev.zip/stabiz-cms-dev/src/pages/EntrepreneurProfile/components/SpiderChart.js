import { Radar } from "@ant-design/charts";

export default function SpiderChart() {
  const data = [
    { name: "Speed", star: 10178 },
    { name: "Agility", star: 7077 },
    { name: "Strength", star: 7345 },
    { name: "Resistance", star: 2029 },
    { name: "Team power", star: 298 },
  ];
  const config = {
    data: data.map((d) => ({ ...d, star: Math.log(d.star).toFixed(2) })),
    xField: "name",
    yField: "star",
    meta: {
      star: {
        alias: "value",
        min: 0,
        nice: true,
      },
    },
    xAxis: {
      line: null,
      tickLine: null,
    },
    yAxis: {
      label: false,
      grid: {
        alternateColor: "rgba(0, 0, 0, 0.04)",
      },
    },
    point: {},
    area: {},
  };
  return (
    <div style={{ height: "15rem" }}>
      <Radar {...config} />
    </div>
  );
}
