/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable import/prefer-default-export */
import { yupResolver } from "@hookform/resolvers/yup";
import {
  createIncomeValueList,
  createValidationErrMessages,
  createValueLabelArr,
  formatDate,
} from "@shared/utils";
import { Button, Divider, message } from "antd";
import moment from "moment";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { useMutation } from "react-query";
import { useHistory } from "react-router-dom";
import {
  DateInput,
  EditDetail,
  SelectInput,
  TextInput,
} from "shared/components/Profile";

import { editDetailsSchema } from "../edit-validation";
import { formatUserFormDefaultValues } from "../formatDefaultValues";
import {
  useAllPrefectures,
  useAreas,
  useEduBackgrounds,
  useIncomes,
  useIndustries,
  useLangLevels,
  useManagementExperiences,
  useOccupations,
  usePositions,
  usePresentPosts,
  useWorkingStatuses,
} from "../useFormValues";
import { editUser, getPrefecture } from "./userDetails.service";

export function EditDetails({
  userDetailsData,
  onModeChange,
  refetchEditedUser,
}) {
  const { t } = useTranslation();
  const [userDetails] = useState(() => ({
    ...formatUserFormDefaultValues(userDetailsData),
  }));

  return (
    <div>
      <div className="flex">
        <Button
          type="primary"
          style={{ marginLeft: "auto" }}
          onClick={() => {
            onModeChange("view");
          }}
        >
          {`<<`}
        </Button>
      </div>

      <div className="flex flex-col" style={{ marginTop: "2rem" }}>
        <EditForm
          userData={userDetails}
          onModeChange={onModeChange}
          refetchEditedUser={refetchEditedUser}
        />
      </div>
    </div>
  );
}

function EditForm({ userData, onModeChange, refetchEditedUser }) {
  const { t } = useTranslation();

  /* ---- Get API values ---- */
  const areasResult = useAreas();
  const industriesResult = useIndustries();
  const positionsResult = usePositions();
  const allPrefecturesResult = useAllPrefectures();

  const eduBackgroundsResult = useEduBackgrounds();

  const workingStatusesResult = useWorkingStatuses();

  const presentPostsResult = usePresentPosts();
  const occupationsResult = useOccupations();
  const langLevelsResult = useLangLevels();
  const managementExperiencesResult = useManagementExperiences();

  /* ---- Incomes value ---- */
  const incomesResult = useIncomes();

  const [incomesList, setIncomesList] = useState([]);

  useEffect(() => {
    if (incomesResult?.data?.data) {
      setIncomesList(() => createIncomeValueList(incomesResult?.data?.data));
    }
  }, [incomesResult.data]);

  /* ---- Create the options for select input ---- */
  const areaIdOptions = createValueLabelArr(areasResult?.data?.data, "name");
  const industryOptions = createValueLabelArr(
    industriesResult?.data?.data,
    "name"
  );
  const allPrefectureOptions = createValueLabelArr(
    allPrefecturesResult?.data?.data,
    "name"
  );
  const positionOptions = createValueLabelArr(
    positionsResult?.data?.data,
    "name"
  );
  const eduBackgroudOptions = createValueLabelArr(
    eduBackgroundsResult?.data?.data,
    "label"
  );
  const workingStatusOptions = createValueLabelArr(
    workingStatusesResult?.data?.data,
    "label"
  );
  const langLevelOptions = createValueLabelArr(
    langLevelsResult?.data?.data,
    "level"
  );
  const presentPostOptions = createValueLabelArr(
    presentPostsResult?.data?.data,
    "name"
  );
  const occupationOptions = createValueLabelArr(
    occupationsResult?.data?.data,
    "name"
  );
  const managementExperienceOptions = createValueLabelArr(
    managementExperiencesResult?.data?.data,
    "exp"
  );

  const {
    watch,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(editDetailsSchema),
    defaultValues: userData,
  });

  useEffect(() => {
    if (
      errors && // 👈 null and undefined check
      Object.keys(errors).length > 0
    ) {
      message.error("すべての必須項目を入力してください");
    }
  }, [errors]);

  const [prefectures, setPrefectures] = useState();

  const prefectureOptions =
    createValueLabelArr(prefectures?.data, "name") || [];

  // Get prefectures from selected area
  const selectedArea = watch("area_id");

  useEffect(() => {
    getPrefecture(selectedArea?.toString()).then((data) => {
      setPrefectures(data);
    });
  }, [selectedArea]);

  const editMutation = useMutation((data) => editUser(data, userData?.id), {
    onSuccess: () => {
      refetchEditedUser();
      message.success(`${t("Entrepreneur Updated Successfully")}`);
      onModeChange("view");
      // history.push("/founders");
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });
  const onSubmit = (formValues) => {
    const values = {
      ...formValues,
      dob: formatDate(formValues.dob),
      work_start_date: formatDate(formValues.work_start_date),
    };

    editMutation.mutate(values);
  };

  if (
    !areasResult.data ||
    !industriesResult.data ||
    !positionsResult.data ||
    !allPrefecturesResult.data ||
    !eduBackgroundsResult.data ||
    !workingStatusesResult.data ||
    !presentPostsResult.data ||
    !occupationsResult.data ||
    !langLevelsResult.data ||
    !managementExperiencesResult.data ||
    !incomesResult.data ||
    incomesList.length === 0
  ) {
    return null;
  }

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        <EditDetail heading="Email">
          <Controller
            control={control}
            name="email"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="last_name">
          <Controller
            control={control}
            name="last_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="first_name">
          <Controller
            control={control}
            name="first_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="last_name_cana">
          <Controller
            control={control}
            name="last_name_cana"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="first_name_cana">
          <Controller
            control={control}
            name="first_name_cana"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="gender">
          <Controller
            control={control}
            name="gender"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={[
                  { value: "male", label: "男性" },
                  { value: "female", label: "女性" },
                  { value: "other", label: "その他" },
                ]}
              />
            )}
          />
        </EditDetail>

        {/* DATE */}
        <EditDetail heading="dob">
          <Controller
            control={control}
            name="dob"
            render={({ field }) => (
              <DateInput
                {...field}
                disabledDate={(current) =>
                  current && current > moment().endOf("day")
                }
              />
            )}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="area">
          <Controller
            control={control}
            name="area_id"
            render={({ field }) => (
              <SelectInput {...field} options={areaIdOptions} />
            )}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="prefecture">
          <Controller
            control={control}
            name="prefecture_id"
            render={({ field }) => (
              <SelectInput {...field} options={prefectureOptions} />
            )}
          />
        </EditDetail>

        <EditDetail heading="address">
          <Controller
            control={control}
            name="address"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="income">
          <Controller
            control={control}
            name="income_range_id"
            render={({ field }) => (
              <SelectInput {...field} options={incomesList} />
            )}
          />
        </EditDetail>

        <Divider orientation="left" style={{ marginTop: "2rem" }}>
          {t("Education")}
        </Divider>
        {/* SELECT */}
        <EditDetail heading="education_background">
          <Controller
            control={control}
            name="education_background_id"
            render={({ field }) => (
              <SelectInput {...field} options={eduBackgroudOptions} />
            )}
          />
        </EditDetail>
        <EditDetail heading="school_name">
          <Controller
            control={control}
            name="school_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="school_major">
          <Controller
            control={control}
            name="school_major"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>

        <Divider orientation="left" style={{ marginTop: "2rem" }}>
          {t("work")}
        </Divider>
        <EditDetail heading="Working Status">
          <Controller
            control={control}
            name="working_status_id"
            render={({ field }) => (
              <SelectInput {...field} options={workingStatusOptions} />
            )}
          />
        </EditDetail>
        <EditDetail heading="Present Company">
          <Controller
            control={control}
            name="present_company"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Present Post">
          <Controller
            control={control}
            name="present_post_id"
            render={({ field }) => (
              <SelectInput {...field} options={presentPostOptions} />
            )}
          />
        </EditDetail>
        <EditDetail heading="Occupation">
          <Controller
            control={control}
            name="occupation_id"
            render={({ field }) => (
              <SelectInput {...field} options={occupationOptions} />
            )}
          />
        </EditDetail>
        <EditDetail heading="Industry">
          <Controller
            control={control}
            name="industry_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={industryOptions}
                mode="multiple"
                multiLimit={3}
              />
            )}
          />
        </EditDetail>
        <EditDetail heading="Transfer">
          <Controller
            control={control}
            name="transfer"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={[
                  { value: "yes", label: "yes" },
                  { value: "no", label: "no" },
                  {
                    value: "only domestic",
                    label: "only domestic",
                  },
                  {
                    value: "only overseas",
                    label: "only overseas",
                  },
                ]}
              />
            )}
          />
        </EditDetail>
        <EditDetail heading="english_language_level">
          <Controller
            control={control}
            name="en_lang_level_id"
            render={({ field }) => (
              <SelectInput {...field} options={langLevelOptions} />
            )}
          />
        </EditDetail>
        <EditDetail heading="has_management_experience">
          <Controller
            control={control}
            name="management_exp_id"
            render={({ field }) => (
              <SelectInput {...field} options={managementExperienceOptions} />
            )}
          />
        </EditDetail>

        <Divider orientation="left" style={{ marginTop: "2rem" }}>
          {t("preference")}
        </Divider>
        <EditDetail heading="Preferred Positions">
          <Controller
            control={control}
            name="pfd_position_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={positionOptions}
                mode="multiple"
                multiLimit={3}
              />
            )}
          />
        </EditDetail>
        <EditDetail heading="Preferred Industries">
          <Controller
            control={control}
            name="pfd_industry_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={industryOptions}
                mode="multiple"
                multiLimit={3}
              />
            )}
          />
        </EditDetail>
        <EditDetail heading="Preferred Prefectures">
          <Controller
            control={control}
            name="pfd_prefecture_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={allPrefectureOptions?.filter(
                  (v) => !v.label.includes("その他")
                )}
                mode="multiple"
                multiLimit={3}
              />
            )}
          />
        </EditDetail>
        <EditDetail heading="Expected Income range">
          <Controller
            control={control}
            name="expected_income_range_id"
            render={({ field }) => (
              <SelectInput {...field} options={incomesList} />
            )}
          />
        </EditDetail>
        {/* DATE */}
        <EditDetail heading="Work start date">
          <Controller
            control={control}
            name="work_start_date"
            render={({ field }) => (
              <DateInput
                {...field}
                disabledDate={(current) =>
                  current && current < moment().endOf("day")
                }
              />
            )}
          />
        </EditDetail>
        <Button
          type="primary"
          htmlType="submit"
          size="large"
          style={{ marginLeft: "auto", marginTop: "2rem", width: "100%" }}
          disabled={editMutation.isLoading}
        >
          {t("Submit")}
        </Button>
      </form>
    </div>
  );
}
