import { createValidationErrMessages } from "@shared/utils";
import { Button, Divider, Dropdown, Input, Menu, message, Select } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery } from "react-query";
import { useHistory } from "react-router-dom";

import {
  editUser,
  getArea,
  getEducationBackground,
  getIncome,
  getIndustryExp,
  getOccupation,
  getPfdPrefectures,
  getPrefecture,
  getPresentPost,
  getWorkingStatus,
} from "./userDetails.service";

const { Option } = Select;

export default function UserDetails({ userDetailsData }) {
  const { t } = useTranslation();
  const history = useHistory();

  const areasResult = useQuery("Area", () => getArea());
  const educationBackgroundsResult = useQuery("Education Background", () =>
    getEducationBackground()
  );
  const workingStatusesResult = useQuery("Working Status", () =>
    getWorkingStatus()
  );
  const occupationsResult = useQuery("Occupation", () => getOccupation());
  const presentPostsResult = useQuery("Present Post", () => getPresentPost());

  const incomesResult = useQuery("Expected Income", () => getIncome());

  const industryExperiencesResult = useQuery("Industry Experiences", () =>
    getIndustryExp()
  );

  const preferredIndustriesResult = useQuery("Industry Preferred", () =>
    getIndustryExp()
  );

  const preferredPrefecturesResult = useQuery("Preferred Prefectures", () =>
    getPfdPrefectures()
  );

  const [edit, setEdit] = useState(false);
  const [FirstName, setFirstName] = useState(first_name);
  const [LastName, setLastName] = useState(last_name);
  const [Age, setAge] = useState(age);
  const [Address, setAddress] = useState(address);
  const [SchoolName, setSchoolName] = useState(school_name);
  const [Area, setArea] = useState(area);
  const [Prefecture, setPrefecture] = useState(prefecture);
  const [EducationBackground, setEducationBackground] =
    useState(education_background);
  const [WorkingStatus, setWorkingStatus] = useState(working_status);
  const [Occupation, setOccupation] = useState(occupation);
  const [PresentPost, setPresentPost] = useState(present_post);
  const [PresentCompany, setPresentCompany] = useState(present_company);
  const [ExpectedIncome, setExpectedIncome] = useState(expected_income);

  const names =
    industries_exp[0].id !== null &&
    industries_exp.map(function (item) {
      return item.id.toString();
    });
  const [IndustryExp, setIndustryExp] = useState(names);

  const names_pfd =
    industries_pfd[0].id !== null &&
    industries_pfd.map(function (item) {
      return item.id.toString();
    });
  const [IndustryPfd, setIndustryPfd] = useState(names_pfd);

  const names_pfd_prefectures =
    prefectures_pfd[0].id !== null &&
    prefectures_pfd.map(function (item) {
      return item.id.toString();
    });
  const [PrefecturesPfd, setPrefecturesPfd] = useState(names_pfd_prefectures);

  const prefecturesResult = useQuery("Prefecture", () =>
    getPrefecture(Area.id)
  );

  useEffect(() => {
    prefecturesResult.refetch();
  }, [Area]);

  const onEdit = (values) => {
    EditMutation.mutate(values);
  };

  function handleButtonClick(e) {
    // message.info("Click on left button.");
    // console.log("click left button", e);
  }

  function handleAreaMenuClick(key, name) {
    // message.info("Click on menu item.");
    setArea({ id: key, name });
  }

  function handleEducationBackgroundMenuClick(key, label) {
    // message.info("Click on menu item.");
    // console.log(key, name);
    setEducationBackground({ id: key, label });
  }

  function handlePrefectureMenuClick(key, name) {
    // message.info("Click on menu item.");
    setPrefecture({ id: key, name, area_id: Area.id });
  }

  function handleWorkingStatusMenuClick(key, label) {
    // message.info("Click on menu item.");
    setWorkingStatus({ id: key, label });
  }

  function handleOccupationMenuClick(key, name) {
    // message.info("Click on menu item.");
    setOccupation({ id: key, name });
  }

  function handlePresentPostMenuClick(key, name) {
    // message.info("Click on menu item.");
    setPresentPost({ id: key, name });
  }

  function handleExpectedIncomeMenuClick(
    key,
    lower_limit,
    upper_limit,
    unit,
    currency
  ) {
    // message.info("Click on menu item.");
    setExpectedIncome({ id: key, lower_limit, upper_limit, unit, currency });
  }

  const areaMenu = (
    <Menu>
      {areas &&
        areas.data.map((a) => (
          <Menu.Item
            onClick={() => handleAreaMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const prefectureMenu = (
    <Menu>
      {prefectures &&
        prefectures.data.map((a) => (
          <Menu.Item
            onClick={() => handlePrefectureMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const EducationBackgroundMenu = (
    <Menu>
      {educationBackgrounds &&
        educationBackgrounds.data.map((a) => (
          <Menu.Item
            onClick={() => handleEducationBackgroundMenuClick(a.id, a.label)}
            key={a.id}
          >
            {a.label}
          </Menu.Item>
        ))}
    </Menu>
  );

  const WorkingStatusMenu = (
    <Menu>
      {workingStatuses &&
        workingStatuses.data.map((a) => (
          <Menu.Item
            onClick={() => handleWorkingStatusMenuClick(a.id, a.label)}
            key={a.id}
          >
            {a.label}
          </Menu.Item>
        ))}
    </Menu>
  );

  const occupationMenu = (
    <Menu>
      {occupations &&
        occupations.data.map((a) => (
          <Menu.Item
            onClick={() => handleOccupationMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const presentPostMenu = (
    <Menu>
      {presentPosts &&
        presentPosts.data.map((a) => (
          <Menu.Item
            onClick={() => handlePresentPostMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const industryExpMenu = (
    <>
      {industryExps &&
        industryExps.data.map((ind) => (
          <Option key={ind.id}>{ind.name}</Option>
        ))}
    </>
  );

  const industryPfdMenu = (
    <>
      {industryPfds &&
        industryPfds.data.map((ind) => (
          <Option key={ind.id}>{ind.name}</Option>
        ))}
    </>
  );

  const PrefecturesPfdMenu = (
    <>
      {prefecturesPfds &&
        prefecturesPfds.data.map((ind) => (
          <Option key={ind.id}>{ind.name}</Option>
        ))}
    </>
  );

  const ExpectedIncomeMenu = (
    <Menu>
      {expectedIncomes &&
        expectedIncomes.data.map((a) => (
          <Menu.Item
            onClick={() =>
              handleExpectedIncomeMenuClick(
                a.id,
                a.lower_limit,
                a.upper_limit,
                a.unit,
                a.currency
              )
            }
            key={a.id}
          >
            {a.lower_limit === null
              ? `${a.upper_limit} ${a.unit}`
              : a.upper_limit === null
              ? `${a.lower_limit} ${a.unit}`
              : `${a.lower_limit} - ${a.upper_limit} ${a.unit}`}
          </Menu.Item>
        ))}
    </Menu>
  );

  function handleChange(value) {
    // console.log(`Selected: ${value}`);
    // console.log(value);
    setIndustryExp(value);
    // setNewData(value);

    // console.log(arr[0]);
  }
  function handleChangePfd(value) {
    // console.log(`Selected: ${value}`);
    // console.log(value);
    setIndustryPfd(value);
    // setNewData(value);

    // console.log(arr[0]);
  }

  function handleChangePrefecturesPfd(value) {
    // console.log(`Selected: ${value}`);
    // console.log(value);
    setPrefecturesPfd(value);
    // setNewData(value);

    // console.log(arr[0]);
  }

  const [currentMode, setCurrentMode] = useState("view");
  const [userDetails, setUserDetails] = useState(() => ({
    ...userDetailsData,
    ...userDetailsData.founder_profile,
    affiliated_companies:
      userDetailsData?.founder_profile?.affiliated_companies?.join(","),
    major_stock_holders:
      userDetailsData?.founder_profile?.major_stock_holders?.join(","),
  }));

  return (
    <div>
      {currentMode === "view" ? (
        <div>
          <div className="flex">
            <Button
              type="primary"
              style={{ marginLeft: "auto" }}
              onClick={() => {
                setEdit(true);
              }}
            >
              {t("Edit")}
            </Button>
          </div>

          {/* ADDRESS */}
          <div className="flex flex-col" style={{ marginTop: "2rem" }}>
            <Detail heading={t("Address")} data={address} />
            <Detail heading={t("Area")} data={area?.name} />
            <Detail heading={t("Prefecture")} data={prefecture?.name} />
            <Detail
              heading={t("income")}
              data={
                income?.lower_limit === null
                  ? `${income?.upper_limit} ${income?.unit}`
                  : income?.upper_limit === null
                  ? `${income?.lower_limit} ${income?.unit}`
                  : `${income?.lower_limit} - ${income?.upper_limit} ${income?.unit}`
              }
            />
          </div>

          {/* EDUCATION */}
          <Divider orientation="left" style={{ marginTop: "2rem" }}>
            {t("Education")}
          </Divider>
          <div className="flex flex-col">
            <Detail
              heading={t("educational_background")}
              data={education_background?.label}
            />
            <Detail heading={t("school_name")} data={school_name} />
            <Detail
              heading={t("language_ability")}
              data={lang_ability?.level}
            />
            <Detail
              heading={t("eng_lang_ability")}
              data={en_lang_ability?.level}
            />
          </div>

          {/* PROFESSIONAL */}
          <Divider orientation="left" style={{ marginTop: "2rem" }}>
            {t("work")}
          </Divider>
          <div className="flex flex-col">
            <Detail
              heading={t("working_status")}
              data={working_status?.label}
            />
            <Detail heading={t("occupation")} data={occupation?.name} />
            <Detail heading={t("present_post")} data={present_post?.name} />
            <Detail heading={t("present_company")} data={present_company} />
            {/* </div> */}
            {/* <div className="mt-4 flex space-x-8"> */}
            {/* <Detail
              heading={t("has_management_experience")}
              data={has_mgmt_exp ? "Yes" : "No"}
            /> */}

            <Detail
              heading={t("industry_experiences")}
              data={industries_exp?.map((i) => i?.name).join(", ")}
            />
          </div>

          <Divider orientation="left" style={{ marginTop: "2rem" }}>
            {t("preference")}
          </Divider>
          <div className="flex flex-col">
            <Detail
              heading={t("prefered_industries")}
              data={industries_pfd?.map((i) => i?.name).join(",")}
            />
            <Detail
              heading={t("prefered_prefectures")}
              data={prefectures_pfd?.map((i) => i?.name).join(",")}
            />
            <Detail
              heading={t("expected_income")}
              data={
                expected_income?.lower_limit === null
                  ? `${expected_income?.upper_limit} ${expected_income?.unit}`
                  : expected_income?.upper_limit === null
                  ? `${expected_income?.lower_limit} ${expected_income?.unit}`
                  : `${expected_income?.lower_limit} - ${expected_income?.upper_limit} ${expected_income?.unit}`
              }
            />
          </div>
        </div>
      ) : (
        <EditDetails
          currentMode={currentMode}
          onModeChange={setCurrentMode}
          userDetailsData={userDetails}
        />
      )}
    </div>
  );
}

function Detail({ heading, data }) {
  return (
    <div className="flex border border-gray-200 border-solid">
      <div
        className="bg-gray-300 px-4 py-2 w-36 rounded-sm rounded-tr-none rounded-tl-none"
        style={{
          width: "25%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <p
          className="text-sm opacity-90 font-semibold mb-0"
          style={{
            textAlign: "center",
          }}
        >
          {heading}
        </p>
      </div>
      <div className="px-4 py-2 w-100">
        <p className="text-base mb-0">{data || "-"}</p>
      </div>
    </div>
  );
}
