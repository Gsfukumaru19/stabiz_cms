import { DownOutlined, UserOutlined } from "@ant-design/icons";
import { Button, Dropdown, Input, Menu, message, Select } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery } from "react-query";

import {
  getOccupation,
  getPresentPost,
  getWorkingStatus,
} from "./userDetails.service";

const { Option } = Select;

export default function SearchEnt({
  inputValues,
  onReset,
  onSearch,
  onSearchInputChange,
  isSearchOn,
  clearFilter,
}) {
  const { t } = useTranslation();

  const { data: workingStatuses, status: wsStatus } = useQuery(
    "Search Working Status",
    () => getWorkingStatus()
  );
  const { data: occupations, status: occupationStatus } = useQuery(
    "Search Occupation",
    () => getOccupation()
  );

  const { data: presentPosts, status: presentPostStatus } = useQuery(
    "Search Present Post",
    () => getPresentPost()
  );

  const [WorkingStatus, setWorkingStatus] = useState({
    id: null,
    label: "        ",
  });
  const [Occupation, setOccupation] = useState({
    id: null,
    name: "        ",
  });
  const [PresentPost, setPresentPost] = useState({
    id: null,
    name: "        ",
  });

  function handleWorkingStatusMenuClick(key, label) {
    // message.info("Click on menu item.");
    setWorkingStatus({ id: key, label });
    onSearchInputChange("working_status_id", key);
  }

  function handleOccupationMenuClick(key, name) {
    // message.info("Click on menu item.");
    setOccupation({ id: key, name });
    onSearchInputChange("occupation_id", key);
  }

  function handlePresentPostMenuClick(key, name) {
    // message.info("Click on menu item.");
    setPresentPost({ id: key, name });
    onSearchInputChange("present_post_id", key);
  }

  const WorkingStatusMenu = (
    <Menu>
      {workingStatuses &&
        workingStatuses.data.map((a) => (
          <Menu.Item
            onClick={() => handleWorkingStatusMenuClick(a.id, a.label)}
            key={a.id}
          >
            {a.label}
          </Menu.Item>
        ))}
    </Menu>
  );

  const occupationMenu = (
    <Menu>
      {occupations &&
        occupations.data.map((a) => (
          <Menu.Item
            onClick={() => handleOccupationMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const presentPostMenu = (
    <Menu>
      {presentPosts &&
        presentPosts.data.map((a) => (
          <Menu.Item
            onClick={() => handlePresentPostMenuClick(a.id, a.name)}
            key={a.id}
          >
            {a.name}
          </Menu.Item>
        ))}
    </Menu>
  );

  const clearSearchFilter = (e) => {
    e.preventDefault();
    clearFilter();
    setWorkingStatus({ id: null, label: "        " });
    setOccupation({ id: null, name: "        " });
    setPresentPost({ id: null, name: "        " });
  };

  const onSearchReset = (e) => {
    e.preventDefault();
    onReset();
    setWorkingStatus({ id: null, label: "        " });
    setOccupation({ id: null, name: "        " });
    setPresentPost({ id: null, name: "        " });
  };

  function handlegenderMenuClick(e) {
    // console.log("click", e.key);
    onSearchInputChange("gender", e.key);
  }
  const genderMenu = (
    <Menu onClick={handlegenderMenuClick}>
      <Menu.Item key="male">{t("male")}</Menu.Item>
      <Menu.Item key="female">{t("female")}</Menu.Item>
      <Menu.Item key="others">{t("others")}</Menu.Item>
    </Menu>
  );

  return (
    <>
      {/* ROW 1 */}
      <div className="flex justify-between">
        <div className="w-35">
          <p>{t("Name")}</p>
          <Input
            value={inputValues?.name}
            onChange={(e) => onSearchInputChange("name", e.target.value)}
          />
        </div>

        <div className="w-35">
          <p>{t("Age Greater Than")}</p>
          <Input
            type="number"
            value={inputValues?.age_greater_than}
            onChange={(e) =>
              onSearchInputChange("age_greater_than", e.target.value)
            }
          />
        </div>

        <div className="w-35">
          <p>{t("Age Less Than")}</p>
          <Input
            type="number"
            value={inputValues?.age_lower_than}
            onChange={(e) =>
              onSearchInputChange("age_lower_than", e.target.value)
            }
          />
        </div>
      </div>{" "}
      <br />
      {/* ROW 2 */}
      <div className="flex justify-between">
        <div className="w-35">
          <p>{t("gender")}</p>
          <Dropdown overlay={genderMenu}>
            <Button>
              {inputValues?.gender && t(`${inputValues?.gender}`)}{" "}
              <DownOutlined />
            </Button>
          </Dropdown>
        </div>
        <div className="w-35">
          <p>{t("school_name")}</p>
          <Input
            value={inputValues?.school_name}
            onChange={(e) => onSearchInputChange("school_name", e.target.value)}
          />
        </div>
        <div className="w-35">
          <p>{t("School Major")}</p>
          <Input
            value={inputValues?.school_major}
            onChange={(e) =>
              onSearchInputChange("school_major", e.target.value)
            }
          />
        </div>{" "}
      </div>
      <br />
      {/* ROW 3 */}
      <div className="flex justify-between">
        <div className="w-35">
          <p>{t("present_company")}</p>
          <Input
            value={inputValues?.present_company}
            onChange={(e) =>
              onSearchInputChange("present_company", e.target.value)
            }
          />
        </div>
        <div className="w-35">
          <p>{t("working_status")}</p>
          <Dropdown.Button overlay={WorkingStatusMenu}>
            {WorkingStatus.label}
          </Dropdown.Button>
        </div>
        <div className="w-35">
          <p>{t("occupation")}</p>
          <Dropdown.Button overlay={occupationMenu}>
            {Occupation.name}
          </Dropdown.Button>
        </div>
        <div className="w-35">
          <p>{t("present_post")}</p>
          <Dropdown.Button overlay={presentPostMenu}>
            {PresentPost.name}
          </Dropdown.Button>
        </div>
      </div>
      <div className="mt-1">
        <Button type="primary" onClick={onSearch}>
          {isSearchOn ? t("Search again") : t("Search")}
        </Button>
        {isSearchOn && (
          <Button className="ml-1" type="secondary" onClick={onSearchReset}>
            {t("Close search")}
          </Button>
        )}
        <Button className="ml-1" type="primary" onClick={clearSearchFilter}>
          {t("Clear Filter")}
        </Button>
      </div>
    </>
  );
}
