import React from "react";

import RecommendSearch from "./RecommendSearch";

const RecommendTab = (userDetails) => {
  return (
    <div>
      <RecommendSearch userDetails={userDetails} />
    </div>
  );
};

export default RecommendTab;
