import { fetchDiagnosisUser, fetchUser } from "@shared/services";
import { Col, Row } from "antd";
import { useQuery } from "react-query";
import { useParams } from "react-router-dom";

import DetailsContainer from "./components/DetailsContainer";
import LeftContainer from "./components/LeftContainer";

export default function FounderProfile() {
  const { userId } = useParams();

  const founderResult = useQuery("founder", () => fetchUser(userId), {
    cacheTime: 0,
  });
  const diagnosisUserResult = useQuery("diagnosisUser", () =>
    fetchDiagnosisUser({ userId })
  );
  return (
    <div>
      <Row gutter={0}>
        <Col span={8}>
          <LeftContainer userDetails={founderResult?.data?.data || {}} />
        </Col>
        <Col span={16}>
          {founderResult?.data?.data && (
            <DetailsContainer
              userDetails={founderResult?.data?.data}
              refetchEditedUser={founderResult.refetch}
            />
          )}
        </Col>
      </Row>
    </div>
  );
}
