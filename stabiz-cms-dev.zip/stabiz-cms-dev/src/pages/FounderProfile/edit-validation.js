/* eslint-disable import/prefer-default-export */
/* eslint-disable no-irregular-whitespace */
import * as yup from "yup";

export const editDetailsSchema = yup.object().shape({
  last_name: yup.string().required("Required").nullable(),
  last_name_cana: yup
    .string()
    .required("Required")
    .nullable()
    .matches(/^[ぁ-んー　]*$/, {
      message: "姓（ふりがな）はひらがなで入力してください。",
    }),
  first_name: yup.string().required("Required").nullable(),
  first_name_cana: yup
    .string()
    .required("Required")
    .nullable()
    .matches(/^[ぁ-んー　]*$/, {
      message: "名（ふりがな）はひらがなで入力してください。",
    }),

  gender: yup.mixed().required("Required").nullable(),
  dob: yup.string().required("Required").nullable(),
  area_id: yup.number().required("Required").nullable(),
  prefecture_id: yup.number().required("Required").nullable(),
  company_name: yup.string().required("Required").nullable(),
  company_industry_ids: yup
    .array()
    .of(yup.string())
    .required("Required")
    .nullable(),
  is_listed_company: yup.boolean().required("Required").nullable(),
  no_of_employees: yup.string().required("Required").nullable(),
  capital: yup.string().required("Required").nullable(),
  last_year_sales: yup.string().required("Required").nullable(),
  established_on: yup.string().required("Required").nullable(),
  business_partner_company: yup.string().required("Required").nullable(),
  major_bank: yup.string().required("Required").nullable(),
  company_features: yup.string().required("Required").nullable(),
  job_description: yup.string().required("Required").nullable(),
  application_conditions: yup.string().required("Required").nullable(),
  employee_benefits: yup.string().required("Required").nullable(),
  affiliated_companies: yup.string().required("Required").nullable(),
  major_stock_holders: yup.string().required("Required").nullable(),
  pfd_industry_ids: yup
    .array()
    .of(yup.number())
    .required("Required")
    .nullable(),
  pfd_position_ids: yup
    .array()
    .of(yup.number())
    .required("Required")
    .nullable(),
  pfd_prefecture_ids: yup
    .array()
    .of(yup.number())
    .required("Required")
    .nullable(),
  offered_income_range_id: yup.number().required("Required").nullable(),
  income_range_id: yup.mixed().required("Required").nullable(),
  work_start_date_4_entr: yup.string().required("Required").nullable(),
});
