// eslint-disable-next-line import/prefer-default-export
export const formatUserFormDefaultValues = (userObj) => {
  const tempUser = { ...userObj };
  delete tempUser?.founder_profile;

  const formattedValues = userObj?.founder_profile;

  return {
    ...formattedValues,
    ...tempUser,
    area_id: formattedValues.area.id,
    prefecture_id: formattedValues.prefecture.id,
    company_industry_ids: formattedValues.company_industries.map((i) => i.id),
    pfd_industry_ids: formattedValues.pfd_industries.map((i) => i.id),
    pfd_position_ids: formattedValues.pfd_positions.map((i) => i.id),
    pfd_prefecture_ids: formattedValues.pfd_prefectures.map((i) => i.id),
    affiliated_companies: formattedValues.affiliated_companies.join(","),
    major_stock_holders: formattedValues.major_stock_holders.join(","),
    offered_income_range_id: formattedValues.offered_income.id,

    dob: new Date(userObj.dob),
    established_on: new Date(formattedValues.established_on),
    work_start_date_4_entr: formattedValues.work_start_date_4_entr
      ? new Date(formattedValues.work_start_date_4_entr)
      : null,
  };
};
