import { Avatar, Divider, Layout } from "antd";
import { useTranslation } from "react-i18next";

import SpiderChart from "./SpiderChart";
import styles from "./styles.module.scss";

export default function LeftContainer({ userDetails }) {
  const {
    last_name,
    first_name,
    last_name_cana,
    first_name_cana,
    email,
    gender,
    age,
  } = userDetails;
  const { t } = useTranslation();
  return (
    <Layout
      style={{
        minHeight: "95vh",
        height: "108%",
        marginTop: "-32px",
        marginBottom: "-32px",
      }}
    >
      <Layout.Content
        style={{
          margin: "1.5rem 1rem",
          padding: 24,
          paddingTop: 32,
          paddingBottom: 56,
          background: "#fff",
          minHeight: "280px",
          borderRadius: "4px",
        }}
      >
        <div className="flex flex-col items-center">
          {userDetails?.avatar === null ? (
            <div className="h-40 w-[10rem] flex items-center justify-center rounded-full bg-red-500">
              <p className="mb-0" />
            </div>
          ) : (
            <Avatar size={160} src={userDetails?.avatar} />
          )}
          <h2 className="mt-6 mb-2 text-2xl">
            {last_name || "-"} {first_name || "-"}
          </h2>
          <h3 className={(styles.subText, "text-lg")}>
            {last_name_cana || "-"} {first_name_cana || "-"}
          </h3>
          <Divider />
          <div className="flex">
            <ScoreTab title={t("Email")} value={email} />
            {/* <ScoreTab title="Diagnosis Score" value="900" /> */}
            {/* <ScoreTab title="Rated Score" value="755" /> */}
          </div>
          <Divider />
          <div className="flex">
            <ScoreTab
              title={t("gender")}
              value={gender == "male" ? "男" : "女"}
            />
            <ScoreTab title={t("Age")} value={age} />
          </div>
          {/* <p style={{ marginBottom: "1rem" }}>Matched Data</p> */}
          {/* <SpiderChart /> */}
        </div>
      </Layout.Content>
    </Layout>
  );
}

function ScoreTab({ title, value }) {
  return (
    <div className={styles.scoreTab}>
      <p>{title}</p>
      <h1 className="text-base">{value || "-"}</h1>
    </div>
  );
}
