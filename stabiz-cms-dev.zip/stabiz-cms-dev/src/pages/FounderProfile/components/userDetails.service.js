import { handleMutation, handleQuery } from "@shared/services/api-client";

export const editUser = async (reqBody, id) =>
  handleMutation({
    method: "PUT",
    resourceUrl: `/user/fdr/${id}`,
    reqBody,
  });

export const getArea = async () => handleQuery({ resourceUrl: `/area` });
export const getPrefecture = async (area_id) =>
  handleQuery({
    resourceUrl: `/prefecture`,
    queryParams: { area_id },
  });
export const getIncome = async () => handleQuery({ resourceUrl: `/income` });
export const getIndustryExp = async () =>
  handleQuery({ resourceUrl: `/industry` });
export const getPfdPrefectures = async () =>
  handleQuery({ resourceUrl: `/prefecture` });

export const getPfdPositions = async () =>
  handleQuery({ resourceUrl: `/position` });
export const getSearchRecommend = async (queryParams) =>
  handleQuery({
    resourceUrl: `/rec-users-search`,
    queryParams: { ...queryParams },
  });

export const getWorkingStatus = async () =>
  handleQuery({ resourceUrl: `/working-status` });

export const getOccupation = async () =>
  handleQuery({ resourceUrl: `/occupation` });

export const getPresentPost = async () =>
  handleQuery({ resourceUrl: `/present-post` });

export const addRecommend = async (reqBody) =>
  handleMutation({
    method: "POST",
    resourceUrl: `/recommend`,
    reqBody,
  });

export const getRecommendedUsers = async (queryParams, id) =>
  handleQuery({
    resourceUrl: `/recommended-users/${id}`,
    queryParams: { ...queryParams },
  });

export const unrecommendUser = async ({ user, removeUser }) =>
  handleMutation({
    method: "DELETE",
    resourceUrl: `/recommended-users/${user}/${removeUser}`,
  });

export const getDocumentsList = async (queryParams) =>
  handleQuery({
    resourceUrl: `/docs`,
    queryParams: { ...queryParams },
  });

export const getDocumentById = async (result) =>
  handleQuery({
    resourceUrl: `/docs/${result}`,
  });

export const verifyDoc = async (reqBody) =>
  handleMutation({
    method: "POST",
    resourceUrl: `/docs/verify`,
    reqBody,
  });
