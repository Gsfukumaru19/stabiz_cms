/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable import/prefer-default-export */
import { yupResolver } from "@hookform/resolvers/yup";
import {
  createIncomeValueList,
  createValidationErrMessages,
  createValueLabelArr,
  formatDate,
} from "@shared/utils";
import { Button, Divider, message } from "antd";
import moment from "moment";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { useMutation } from "react-query";
import { useHistory } from "react-router-dom";
import {
  DateInput,
  EditDetail,
  SelectInput,
  TextInput,
} from "shared/components/Profile";

import { editDetailsSchema } from "../edit-validation";
import { formatUserFormDefaultValues } from "../formatDefaultValues";
import {
  useAllPrefectures,
  useAreas,
  useIncomes,
  useIndustries,
  usePositions,
} from "../useFormValues";
import { editUser, getPrefecture } from "./userDetails.service";

export function EditDetails({
  userDetailsData,
  onModeChange,
  refetchEditedUser,
}) {
  const { t } = useTranslation();
  const history = useHistory();

  const [userDetails] = useState(() => ({
    ...formatUserFormDefaultValues(userDetailsData),
  }));

  return (
    <div>
      <div className="flex">
        <Button
          type="primary"
          style={{ marginLeft: "auto" }}
          onClick={() => {
            onModeChange("view");
          }}
        >
          {`<<`}
        </Button>
      </div>

      <div className="flex flex-col" style={{ marginTop: "2rem" }}>
        <EditForm
          userData={userDetails}
          onModeChange={onModeChange}
          refetchEditedUser={refetchEditedUser}
        />
      </div>
    </div>
  );
}

function EditForm({ userData, onModeChange, refetchEditedUser }) {
  const { t } = useTranslation();
  /* ---- Get API values ---- */
  const areasResult = useAreas();
  const industriesResult = useIndustries();
  const positionsResult = usePositions();
  const allPrefecturesResult = useAllPrefectures();

  // /* ---- Incomes value ---- */
  const incomesResult = useIncomes();

  const [incomesList, setIncomesList] = useState([]);

  useEffect(() => {
    if (incomesResult?.data?.data) {
      setIncomesList(() => createIncomeValueList(incomesResult?.data?.data));
    }
  }, [incomesResult.data]);

  const areaIdOptions = createValueLabelArr(areasResult?.data?.data, "name");
  const industryOptions = createValueLabelArr(
    industriesResult?.data?.data,
    "name"
  );
  const allPrefectureOptions = createValueLabelArr(
    allPrefecturesResult?.data?.data,
    "name"
  );

  const positionOptions = createValueLabelArr(
    positionsResult?.data?.data,
    "name"
  );

  const {
    watch,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(editDetailsSchema),
    defaultValues: userData,
  });

  useEffect(() => {
    if (
      errors && // 👈 null and undefined check
      Object.keys(errors).length > 0
    ) {
      message.error("すべての必須項目を入力してください");
    }
  }, [errors]);

  const [prefectures, setPrefectures] = useState();

  const prefectureOptions =
    createValueLabelArr(prefectures?.data, "name") || [];

  // Get prefectures from selected area
  const selectedArea = watch("area_id");

  useEffect(() => {
    getPrefecture(selectedArea?.toString()).then((data) => {
      setPrefectures(data);
    });
  }, [selectedArea]);

  const editMutation = useMutation((data) => editUser(data, userData?.id), {
    onSuccess: () => {
      refetchEditedUser();
      message.success(`${t("Founder updated successfully")}`);
      onModeChange("view");
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const onSubmit = (formValues) => {
    const values = {
      ...formValues,
      dob: formatDate(formValues.dob),
      work_start_date_4_entr: formatDate(formValues.work_start_date_4_entr),
      established_on: formatDate(formValues.established_on),
      affiliated_companies: formValues.affiliated_companies.split(","),
      major_stock_holders: formValues.major_stock_holders.split(","),
    };

    editMutation.mutate(values);
  };

  if (
    !areasResult.data ||
    !industriesResult.data ||
    !positionsResult.data ||
    !allPrefecturesResult.data ||
    !incomesResult.data ||
    incomesList.length === 0
  ) {
    return null;
  }

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        <EditDetail heading="email">
          <Controller
            control={control}
            name="email"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="last_name">
          <Controller
            control={control}
            name="last_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="first_name">
          <Controller
            control={control}
            name="first_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="last_name_cana">
          <Controller
            control={control}
            name="last_name_cana"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="first_name_cana">
          <Controller
            control={control}
            name="first_name_cana"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="gender">
          <Controller
            control={control}
            name="gender"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={[
                  { value: "male", label: "男性" },
                  { value: "female", label: "女性" },
                  { value: "other", label: "その他" },
                ]}
              />
            )}
          />
        </EditDetail>

        {/* DATE */}
        <EditDetail heading="dob">
          <Controller
            control={control}
            name="dob"
            render={({ field }) => (
              <DateInput
                {...field}
                disabledDate={(current) =>
                  current && current > moment().endOf("day")
                }
              />
            )}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="area">
          <Controller
            control={control}
            name="area_id"
            render={({ field }) => (
              <SelectInput {...field} options={areaIdOptions} />
            )}
          />
        </EditDetail>
        {/* SELECT */}
        <EditDetail heading="prefecture">
          <Controller
            control={control}
            name="prefecture_id"
            render={({ field }) => (
              <SelectInput {...field} options={prefectureOptions} />
            )}
          />
        </EditDetail>
        {/* SELECT */}
        <EditDetail heading="income">
          <Controller
            control={control}
            name="income_range_id"
            render={({ field }) => (
              <SelectInput {...field} options={incomesList} />
            )}
          />
        </EditDetail>

        {/* Company Details */}
        <Divider orientation="left" style={{ marginTop: "2rem" }}>
          {t("Company Details")}
        </Divider>
        <EditDetail heading="Company Name">
          <Controller
            control={control}
            name="company_name"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        {/* MULTI SELECT */}
        <EditDetail heading="Company Industry">
          <Controller
            control={control}
            name="company_industry_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                mode="multiple"
                multiLimit={3}
                options={industryOptions}
              />
            )}
          />
        </EditDetail>

        {/* SELECT */}
        <EditDetail heading="Is listed company">
          <Controller
            control={control}
            name="is_listed_company"
            render={({ field }) => (
              <SelectInput
                {...field}
                options={[
                  { value: true, label: `${t("Yes")}` },
                  { value: false, label: `${t("No")}` },
                ]}
              />
            )}
          />
        </EditDetail>

        {/* NUMNBER ONLY with RIGHT ADDON */}
        <EditDetail heading="Number of employees">
          <Controller
            control={control}
            name="no_of_employees"
            render={({ field }) => (
              <TextInput
                {...field}
                suffix={<span>人</span>}
                onKeyPress={(event) => {
                  if (!/[0-9]/.test(event.key)) {
                    event.preventDefault();
                  }
                }}
              />
            )}
          />
        </EditDetail>
        {/* NUMBER ONLY RIGHT ADDON */}
        <EditDetail heading="Capital">
          <Controller
            control={control}
            name="capital"
            render={({ field }) => (
              <TextInput
                {...field}
                suffix={<span>千円</span>}
                onKeyPress={(event) => {
                  if (!/[0-9]/.test(event.key)) {
                    event.preventDefault();
                  }
                }}
              />
            )}
          />
        </EditDetail>
        {/* NUMBER ONLY RIGHT ADDON */}
        <EditDetail heading="Last year sales">
          <Controller
            control={control}
            name="last_year_sales"
            render={({ field }) => (
              <TextInput
                {...field}
                suffix={<span>千円</span>}
                onKeyPress={(event) => {
                  if (!/[0-9]/.test(event.key)) {
                    event.preventDefault();
                  }
                }}
              />
            )}
          />
        </EditDetail>

        {/* DATE yyyy/MM */}
        <EditDetail heading="Established On">
          <Controller
            control={control}
            name="established_on"
            render={({ field }) => <DateInput {...field} picker="month" />}
          />
        </EditDetail>
        <EditDetail heading="Business Partner Company">
          <Controller
            control={control}
            name="business_partner_company"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Major Bank">
          <Controller
            control={control}
            name="major_bank"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Company Features">
          <Controller
            control={control}
            name="company_features"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Job Description">
          <Controller
            control={control}
            name="job_description"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Application Condition">
          <Controller
            control={control}
            name="application_conditions"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        <EditDetail heading="Employee Benefits">
          <Controller
            control={control}
            name="employee_benefits"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        {/* COMMA SEPARATED */}
        <EditDetail heading="Affiliated Companies">
          <Controller
            control={control}
            name="affiliated_companies"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>
        {/* COMMA SEPARATED */}
        <EditDetail heading="Major Stock Holders">
          <Controller
            control={control}
            name="major_stock_holders"
            render={({ field }) => <TextInput {...field} />}
          />
        </EditDetail>

        <Divider orientation="left" style={{ marginTop: "2rem" }}>
          {t("preference")}
        </Divider>
        {/* MULTI SELECT */}
        <EditDetail heading="prefered_industries">
          <Controller
            control={control}
            name="pfd_industry_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                multiLimit={3}
                mode="multiple"
                options={industryOptions}
              />
            )}
          />
        </EditDetail>
        {/* MULTI SELECT */}
        <EditDetail heading="Preferred Positions">
          <Controller
            control={control}
            name="pfd_position_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                multiLimit={3}
                mode="multiple"
                options={positionOptions}
              />
            )}
          />
        </EditDetail>
        {/* MULTI SELECT */}
        <EditDetail heading="prefered_prefectures">
          <Controller
            control={control}
            name="pfd_prefecture_ids"
            render={({ field }) => (
              <SelectInput
                {...field}
                multiLimit={3}
                mode="multiple"
                options={allPrefectureOptions?.filter(
                  (v) => !v.label.includes("その他")
                )}
              />
            )}
          />
        </EditDetail>
        {/* SELECT */}
        <EditDetail heading="Offered Income">
          <Controller
            control={control}
            name="offered_income_range_id"
            render={({ field }) => (
              <SelectInput {...field} options={incomesList} />
            )}
          />
        </EditDetail>
        {/* DATE */}
        <EditDetail heading="Work start date For Ent">
          <Controller
            control={control}
            name="work_start_date_4_entr"
            render={({ field }) => (
              <DateInput
                {...field}
                disabledDate={(current) =>
                  current && current < moment().endOf("day")
                }
              />
            )}
          />
        </EditDetail>

        <Button
          type="primary"
          htmlType="submit"
          disabled={editMutation.isLoading}
          size="large"
          style={{ marginLeft: "auto", marginTop: "2rem", width: "100%" }}
        >
          {t("Submit")}
        </Button>
      </form>
    </div>
  );
}
