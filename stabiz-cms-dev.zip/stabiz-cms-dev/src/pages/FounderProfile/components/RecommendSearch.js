import {
  CheckCircleFilled,
  CheckCircleOutlined,
  DeleteTwoTone,
  EditTwoTone,
  EyeOutlined,
  PlusCircleFilled,
  PlusCircleOutlined,
  PlusCircleTwoTone,
} from "@ant-design/icons";
import { BaseTable, SearchPanel, TableSkeleton } from "@shared/components";
import { deleteUser } from "@shared/services";
import { Button, message, Popconfirm } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { Link } from "react-router-dom";

import RecommendedUsers from "./RecommendedUsers";
import SearchEnt from "./SearchEnt";
import { addRecommend, getSearchRecommend } from "./userDetails.service";

export default function RecommendSearch(userDetails) {
  const { t } = useTranslation();

  //   console.log(userDetails.userDetails.userDetails);

  /* ---- Search ---- */
  // TODO: Write search panel mechanism docs
  const [searchParams, setSearchParams] = useState();

  const [isSearchOn, setIsSearchOn] = useState(false);

  const [currCollpaseKey, setCurrCollpaseKey] = useState();

  const [ToggleData, setToggleData] = useState(false);

  const handleInputChange = (key, val) => {
    setSearchParams({
      ...searchParams,
      [key]: val,
    });
  };

  const toggleSearch = () => setIsSearchOn(true);

  const handleReset = () => {
    setCurrCollpaseKey();
    setSearchParams();
    setIsSearchOn(false);
  };

  const clearFilter = () => {
    setSearchParams();
  };

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    current: 1,
    total: null,
  });

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  /* ---- Paginated query ---- */
  const entrepreneursResult = useQuery(
    [
      "recommend Search list",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        user_id: userDetails.userDetails.userDetails.id,
        ...(isSearchOn && { ...searchParams }),
      },
    ],
    () =>
      getSearchRecommend({
        page: paginationCtrl.current,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        user_id: userDetails.userDetails.userDetails.id,
        ...(isSearchOn && { ...searchParams }),
      }),
    { keepPreviousData: true, staleTime: 5000, retry: false }
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (entrepreneursResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: entrepreneursResult.data?.meta.total,
      }));
    }
  }, [entrepreneursResult.data]);

  const AddMutation = useMutation((data) => addRecommend(data), {
    onSuccess: (data) => {
      // Redirect to home
      // history.push("/entrepreneurs");
      message.success(`${t("Recommended successfully")}`);
      entrepreneursResult.refetch();
      setToggleData(!ToggleData);
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const onAddClick = (values) => {
    AddMutation.mutate(values);
  };

  const columns = [
    {
      title: `${t("Name")}`,
      dataIndex: "name",
      key: "name",
      render: (id, record) => (
        <p>
          {record?.last_name} {record?.first_name}
        </p>
      ),
    },
    {
      title: `${t("Email")}`,
      dataIndex: "email",
      key: "email",
    },
    {
      title: `${t("Age")}`,
      dataIndex: "age",
      key: "age",
    },

    // {
    //   title: `${t("Income range")}`,
    //   dataIndex: "incomeRange",
    //   key: "incomeRange",
    // },
    {
      title: `${t("Details")}`,
      key: "id",
      dataIndex: "id",
      render: (id) => (
        <Link to={`/entrepreneur/${id}`}>
          <Button>{t("View profile details")}</Button>
        </Link>
      ),
    },
    {
      title: `${t("Add")}`,
      key: "add",
      dataIndex: "id",
      render: (id) => {
        return (
          <Button
            onClick={() =>
              onAddClick({
                recommended_to_user_id: userDetails.userDetails.userDetails.id,
                recommended_user_id: id,
              })
            }
          >
            <PlusCircleFilled style={{ color: "green" }} />
          </Button>
        );
      },
    },
  ];

  return (
    <>
      <div className="mb-1">
        <SearchPanel
          onReset={handleReset}
          onSearch={toggleSearch}
          isSearchOn={isSearchOn}
          inputValues={searchParams}
          onSearchInputChange={handleInputChange}
          searchComponent={SearchEnt}
          currCollpaseKey={currCollpaseKey}
          setCurrCollpaseKey={setCurrCollpaseKey}
          clearFilter={clearFilter}
        />
      </div>

      {entrepreneursResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <>
          {isSearchOn === true && (
            <>
              <h3>{t("Searched unrecommended user")}</h3>
              <BaseTable
                columns={columns}
                data={entrepreneursResult.data?.data}
                paginationCtrl={paginationCtrl}
                onPageChange={handlePageChange}
              />
            </>
          )}
        </>
      )}

      <RecommendedUsers
        entrepreneur_id={userDetails.userDetails.userDetails.id}
        ToggleData={ToggleData}
      />
    </>
  );
}
