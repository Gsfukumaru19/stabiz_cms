import { CheckCircleTwoTone, CloseCircleTwoTone } from "@ant-design/icons";
import { BaseTable, LoadingSpinner, TableSkeleton } from "@shared/components";
import { Button, Input, message, Modal, Popconfirm } from "antd";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { createValidationErrMessages } from "shared/utils";

import {
  getDocumentById,
  getDocumentsList,
  verifyDoc,
} from "./userDetails.service";

const { TextArea } = Input;

const Documents = ({ userDetails }) => {
  const { t } = useTranslation();
  const [DocId, setDocId] = useState(null);
  const [acceptToggle, setAcceptToggle] = useState(false);
  const [rejectToggle, setRejectToggle] = useState(false);
  const {
    data: uploadedDocuments,
    isLoading,
    error,
    refetch: uploadedRefetch,
  } = useQuery("uploadedDocunents", () =>
    getDocumentsList({ user_id: userDetails.id })
  );
  const [reason, setReason] = useState("");
  const [status, setStatus] = useState("");
  const [Id, setId] = useState(null);

  const {
    status: docStatus,
    data: docData,
    error: docError,
    refetch,
  } = useQuery(["doc", DocId], () => getDocumentById(DocId), {
    manual: true,
    onSuccess: (data) => window.open(data.link, "_blank"),
  });

  const viewDocument = (id) => {
    setDocId(id);
    refetch();
  };

  //    Accept Mutation
  const acceptMutation = useMutation((data) => verifyDoc(data), {
    onSuccess: () => {
      message.success(`${t("Document Approved Successfully")}`);
      uploadedRefetch();
      setAcceptToggle(false);
      setId(null);
      setStatus(null);
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const onAccept = (values) => {
    acceptMutation.mutate(values);
  };

  //    Reject Mutation
  const rejectMutation = useMutation((data) => verifyDoc(data), {
    onSuccess: () => {
      // Redirect to home
      // history.push("/entrepreneurs");
      message.success(`${t("Document Rejected Successfully")}`);
      uploadedRefetch();
      setRejectToggle(false);
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const onReject = (values) => {
    rejectMutation.mutate(values);
  };

  //   console.log(docData);

  const columns = [
    {
      title: `${t("Document Name")}`,
      dataIndex: "doc_name",
      key: "doc_name",
      render: (id, record) => <p>{t(record?.doc_name)}</p>,
    },
    // {
    //   title: `${t("Email")}`,
    //   dataIndex: "email",
    //   key: "email",
    // },
    // {
    //   title: `${t("Age")}`,
    //   dataIndex: "age",
    //   key: "age",
    // },

    // {
    //   title: `${t("Income range")}`,
    //   dataIndex: "incomeRange",
    //   key: "incomeRange",
    // },
    {
      title: `${t("View")}`,
      key: "id",
      dataIndex: "id",
      render: (id) => (
        <Button onClick={() => viewDocument(id)}>{t("View Document")}</Button>
      ),
    },
    {
      //   title: `${t("Add")}`,
      key: "add",
      dataIndex: "id",
      render: (id, record) => {
        return (
          <>
            {record.approved_at !== null ? (
              <CheckCircleTwoTone
                twoToneColor="#52c41a"
                style={{ fontSize: "40px" }}
              />
            ) : record.rejected_at !== null ? (
              <CloseCircleTwoTone
                twoToneColor="#E41313"
                style={{ fontSize: "40px" }}
              />
            ) : (
              <div>
                <Popconfirm
                  title={t("Are you sure?")}
                  //   onConfirm={() => deleteUserMutation.mutate(id)}
                  //   okButtonProps={{
                  //     loading: deleteUserMutation.isLoading,
                  //   }}
                  onConfirm={() => {
                    onAccept({ state: "approved", id: id });
                  }}
                  okText="承認する"
                  cancelText={t("Cancel")}
                >
                  <Button type="primary" ghost>
                    {t("Approve")}
                  </Button>
                </Popconfirm>
                <Popconfirm
                  title="本当に却下しますか？"
                  //   onConfirm={() => deleteUserMutation.mutate(id)}
                  //   okButtonProps={{
                  //     loading: deleteUserMutation.isLoading,
                  //   }}
                  onConfirm={() => {
                    setStatus("rejected");
                    setId(id);
                    setRejectToggle(true);
                  }}
                  okText="却下"
                  cancelText={t("Cancel")}
                >
                  <Button
                    type="primary"
                    danger
                    ghost
                    style={{ marginLeft: "40px" }}
                  >
                    {t("Reject")}
                  </Button>
                </Popconfirm>
              </div>
            )}
          </>
        );
      },
    },
  ];

  const handleRejectOk = () => {
    if (!reason) {
      message.error(`${t("拒否の理由を入力してください")}`);
      return;
    }
    setRejectToggle(false);
    onReject({ state: status, remarks: reason, id: Id });
  };

  const handleRejectCancel = () => {
    setRejectToggle(false);
    setId(null);
    setReason("");
    setStatus("");
  };

  return (
    <>
      {/* {acceptToggle && (
        <Modal
          title={t("Reason")}
          visible={acceptToggle}
          onOk={handleAcceptOk}
          onCancel={handleAcceptCancel}
          okText="送信"
          cancelText={t("Cancel")}
        >
          <TextArea
            rows={4}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
        </Modal>
      )} */}

      {rejectToggle && (
        <Modal
          title={t("Reason")}
          visible={rejectToggle}
          onOk={handleRejectOk}
          onCancel={handleRejectCancel}
          okText="送信"
          cancelText={t("Cancel")}
        >
          <TextArea
            rows={4}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
        </Modal>
      )}
      <div>
        {isLoading ? (
          <TableSkeleton columns={columns} />
        ) : error ? (
          <h1>Error</h1>
        ) : uploadedDocuments.data.length !== 0 ? (
          <BaseTable columns={columns} data={uploadedDocuments?.data} />
        ) : (
          <BaseTable columns={columns} />
        )}
      </div>
    </>
  );
};

export default Documents;
