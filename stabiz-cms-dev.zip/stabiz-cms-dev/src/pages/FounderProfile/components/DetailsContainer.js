import {
  FundOutlined,
  RadarChartOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { ResultCharts, SalesChart } from "@shared/components";
import { Layout, Tabs } from "antd";
import { useTranslation } from "react-i18next";
import { useQuery } from "react-query";

import DocumentsTab from "./DocumentsTab";
import RecommendTab from "./RecommendTab";
import UserDetails from "./UserDetails";

const { TabPane } = Tabs;

export default function DetailsContainer({ userDetails, refetchEditedUser }) {
  const { t } = useTranslation();

  return (
    <Layout
      style={{
        minHeight: "108%",
        marginTop: "-32px",
        marginBottom: "-24px",
      }}
    >
      <Layout.Content
        style={{
          margin: "1.5rem 1rem",
          padding: 24,
          background: "#fff",
          minHeight: "280px",
          borderRadius: "4px",
        }}
      >
        <div>
          <Tabs>
            <TabPane
              tab={
                <span>
                  <UserOutlined />
                  {t("User Details")}
                </span>
              }
              key="1"
            >
              <UserDetails
                userDetailsData={userDetails}
                refetchEditedUser={refetchEditedUser}
              />
            </TabPane>
            {/* <TabPane
              tab={
                <span>
                  <RadarChartOutlined />
                  {t("Results")}
                </span>
              }
              key="2"
            >
              <ResultCharts userDetails={userDetails} />
            </TabPane> */}
            <TabPane
              tab={
                <span>
                  <RadarChartOutlined />
                  {t("recommend user")}
                </span>
              }
              key="3"
            >
              <RecommendTab userDetails={userDetails} />
            </TabPane>

            <TabPane
              tab={
                <span>
                  <RadarChartOutlined />
                  {t("Documents")}
                </span>
              }
              key="4"
            >
              <DocumentsTab userDetails={userDetails} />
            </TabPane>
          </Tabs>
        </div>
      </Layout.Content>
    </Layout>
  );
}

function UserSales() {
  return (
    <div>
      <p className="mb-32">User sale statistics</p>
      <SalesChart />
    </div>
  );
}
