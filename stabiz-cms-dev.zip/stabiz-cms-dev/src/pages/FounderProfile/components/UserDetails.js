import { Button, Divider } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { ProfileDetail } from "shared/components/Profile";
import { formatIncomeRange } from "shared/utils";

import { EditDetails } from "./EditDetails";

export default function UserDetails({ userDetailsData, refetchEditedUser }) {
  const [currentMode, setCurrentMode] = useState("view");
  const userDetails = {
    ...userDetailsData,
    ...userDetailsData?.founder_profile,
  };

  return (
    <div>
      {currentMode === "view" ? (
        <Details data={userDetails} onModeChange={setCurrentMode} />
      ) : (
        <EditDetails
          currentMode={currentMode}
          onModeChange={setCurrentMode}
          userDetailsData={userDetails}
          refetchEditedUser={refetchEditedUser}
        />
      )}
    </div>
  );
}

function Details({ data, onModeChange }) {
  const { t } = useTranslation();
  return (
    <div>
      <div className="flex">
        <Button
          type="primary"
          style={{ marginLeft: "auto" }}
          onClick={() => {
            onModeChange("edit");
          }}
        >
          {t("Edit")}
        </Button>
      </div>

      {/* OWN DETAILS */}
      <div className="flex flex-col" style={{ marginTop: "2rem" }}>
        <ProfileDetail heading="last_name" data={data?.last_name} />
        <ProfileDetail heading="first_name" data={data?.first_name} />
        <ProfileDetail heading="last_name_cana" data={data?.last_name_cana} />
        <ProfileDetail heading="first_name_cana" data={data?.first_name_cana} />
        <ProfileDetail heading="gender" data={t(data?.gender)} />
        <ProfileDetail heading="dob" data={data?.dob} />

        <ProfileDetail heading="area" data={data?.area?.name} />
        <ProfileDetail heading="prefecture" data={data?.prefecture?.name} />
        <ProfileDetail
          heading="income"
          data={formatIncomeRange(data?.income)}
        />
      </div>

      {/* Company Details */}
      <Divider orientation="left" style={{ marginTop: "2rem" }}>
        {t("Company Details")}
      </Divider>
      <div className="flex flex-col">
        <ProfileDetail heading="Company Name" data={data?.company_name} />
        <ProfileDetail
          heading="Company Industry"
          data={data?.company_industries?.map((i) => i.name).join(", ")}
        />
        <ProfileDetail
          heading="Is listed company"
          data={data?.is_listed_company ? "上場" : "非上場"}
        />
        <ProfileDetail
          heading="Number of employees"
          data={`${data?.no_of_employees}人`}
        />
        <ProfileDetail heading="Capital" data={`${data?.capital} 万円`} />

        <ProfileDetail
          heading="Last year sales"
          data={`${data?.last_year_sales} 万円`}
        />
        <ProfileDetail heading="Established On" data={data?.established_on} />
        <ProfileDetail
          heading="Business Partner Company"
          data={data?.business_partner_company}
        />
        <ProfileDetail heading="Major Bank" data={data?.major_bank} />
        <ProfileDetail
          heading="Company Features"
          data={data?.company_features}
        />
        <ProfileDetail heading="Job Description" data={data?.job_description} />
        <ProfileDetail
          heading="Application Condition"
          data={data?.application_conditions}
        />
        <ProfileDetail
          heading="Employee Benefits"
          data={data?.employee_benefits}
        />
        <ProfileDetail
          heading="Affiliated Companies"
          data={data?.affiliated_companies?.join(",")}
        />

        <ProfileDetail
          heading="Major Stock Holders"
          data={data?.major_stock_holders?.join(", ")}
        />
      </div>

      <Divider orientation="left" style={{ marginTop: "2rem" }}>
        {t("preference")}
      </Divider>

      <div className="flex flex-col">
        <ProfileDetail
          heading="prefered_industries"
          data={data?.pfd_industries?.map((i) => i?.name).join(",")}
        />

        <ProfileDetail
          heading="Preferred Positions"
          data={data?.pfd_positions?.map((i) => i?.name).join(",")}
        />
        <ProfileDetail
          heading="prefered_prefectures"
          data={data?.pfd_prefectures?.map((i) => i?.name).join(",")}
        />
        <ProfileDetail
          heading="Offered Income"
          data={formatIncomeRange(data?.offered_income)}
        />
        <ProfileDetail
          heading="Work start date For Ent"
          data={data?.work_start_date_4_entr}
        />
      </div>
    </div>
  );
}
