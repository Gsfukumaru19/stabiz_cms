import React from "react";

import Documents from "./Documents";

const DocumentsTab = ({ userDetails }) => {
  return (
    <div>
      <Documents userDetails={userDetails} />
    </div>
  );
};

export default DocumentsTab;
