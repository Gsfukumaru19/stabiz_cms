import {
  CheckCircleFilled,
  DeleteTwoTone,
  EditTwoTone,
  EyeOutlined,
} from "@ant-design/icons";
import { BaseTable, TableSkeleton } from "@shared/components";
import { Button, message, Popconfirm } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { Link } from "react-router-dom";

import { getRecommendedUsers, unrecommendUser } from "./userDetails.service";

export default function RecommendedUsers({ entrepreneur_id, ToggleData }) {
  const { t } = useTranslation();

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    current: 1,
    total: null,
  });

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const deleteUserMutation = useMutation((data) => unrecommendUser(data), {
    onSuccess: () => {
      message.success(t("Recommended user removed"));
      queryClient.invalidateQueries("entrepreneurs");
      entrepreneursResult.refetch();
    },
    onError: (error) => {
      message.error(error.statusText);
    },
  });

  /* ---- Paginated query ---- */
  const entrepreneursResult = useQuery(
    [
      "recommended founders",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
      },
    ],
    () =>
      getRecommendedUsers(
        {
          page: paginationCtrl.current,
          per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
          user: entrepreneur_id,
        },
        entrepreneur_id
      ),
    { keepPreviousData: true, staleTime: 5000, retry: false }
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (entrepreneursResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: entrepreneursResult.data?.meta.total,
      }));
    }
  }, [entrepreneursResult.data]);

  useEffect(() => {
    // console.log("YESSSSSS");
    entrepreneursResult.refetch();
  }, [ToggleData]);

  const columns = [
    {
      title: `${t("Name")}`,
      dataIndex: "name",
      key: "name",
      render: (id, record) => (
        <p>
          {record.recommended_user?.last_name}{" "}
          {record.recommended_user?.first_name}
        </p>
      ),
    },
    {
      title: `${t("Email")}`,
      dataIndex: "email",
      key: "email",
      render: (id, record) => <p>{record.recommended_user?.email}</p>,
    },
    {
      title: `${t("Age")}`,
      dataIndex: "age",
      key: "age",
      render: (id, record) => <p>{record.recommended_user?.age}</p>,
    },

    {
      title: `${t("Details")}`,
      key: "id",
      dataIndex: "id",
      render: (id, record) => (
        <Link to={`/entrepreneur/${record.recommended_user?.id}`}>
          <Button>{t("View profile details")}</Button>
        </Link>
      ),
    },
    {
      title: `${t("Delete")}`,
      key: "delete",
      dataIndex: "id",
      render: (id, record) => (
        <Popconfirm
          title={t("Are you sure?")}
          onConfirm={() =>
            deleteUserMutation.mutate({
              user: entrepreneur_id,
              removeUser: record.recommended_user.id,
            })
          }
          okButtonProps={{
            loading: deleteUserMutation.isLoading,
          }}
          okText={t("Ok")}
          cancelText={t("Cancel")}
        >
          <Button>
            <DeleteTwoTone twoToneColor="#ff4d4f" />
          </Button>
        </Popconfirm>
      ),
    },
  ];

  // console.log(ModalData);

  return (
    <>
      <h3>{t("Recommended user")}</h3>
      {entrepreneursResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <BaseTable
          columns={columns}
          data={entrepreneursResult.data?.data}
          paginationCtrl={paginationCtrl}
          onPageChange={handlePageChange}
        />
      )}
    </>
  );
}
