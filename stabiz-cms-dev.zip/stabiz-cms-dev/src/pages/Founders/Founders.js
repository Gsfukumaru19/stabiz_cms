import { PaddedLayout, SearchInput } from "@shared/components";

import FoundersTable from "./components/FoundersTable";

export default function Founders() {
  return (
    <PaddedLayout>
      <div>
        {/* <div style={{ width: "20rem", marginBottom: "2rem" }}>
          <SearchInput placeholder="Search founders" />
        </div> */}
        <FoundersTable />
      </div>
    </PaddedLayout>
  );
}
