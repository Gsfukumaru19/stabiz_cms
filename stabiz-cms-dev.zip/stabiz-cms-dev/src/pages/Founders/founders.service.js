import { handleQuery } from "@shared/services/api-client";

export const fetchFounders = async (queryParams) =>
  handleQuery({
    resourceUrl: `/users`,
    queryParams: { type: "founder", ...queryParams },
  });

export const fetchAssignUsers = async (queryParams) =>
  handleQuery({
    resourceUrl: `/assign-users`,
    queryParams: { ...queryParams },
  });

export const fetchStaffs = async (queryParams) =>
  handleQuery({ resourceUrl: `/staff`, queryParams });

export const postAssign = async (reqBody) =>
  handleMutation({ method: "POST", resourceUrl: `/assign-users`, reqBody });
