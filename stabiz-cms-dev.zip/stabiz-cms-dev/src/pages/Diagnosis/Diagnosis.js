import { PaddedLayout } from "@shared/components";

export default function Diagnosis() {
  return (
    <PaddedLayout>
      <div>
        <h2>Content of Diagnosis</h2>
      </div>
    </PaddedLayout>
  );
}
