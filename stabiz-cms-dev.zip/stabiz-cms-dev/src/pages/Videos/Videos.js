import { CreateButton, PaddedLayout } from "@shared/components";
import { Button, Modal } from "antd";
import { useState } from "react";

import CreateModal from "./components/CreateModal";
import VideosTable from "./components/VideosTable";

export default function Staffs() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  return (
    <>
      <CreateModal
        isModalVisible={isCreateModalOpen}
        onModalClose={() => setIsCreateModalOpen(false)}
      />
      <PaddedLayout>
        <div>
          <div className="flex flex-row-reverse">
            <CreateButton
              onClick={() => setIsCreateModalOpen(true)}
              buttonText="Video"
            />
          </div>
          <VideosTable />
        </div>
      </PaddedLayout>
    </>
  );
}
