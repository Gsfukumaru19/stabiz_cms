import { BaseModal } from "@shared/components";
import { createValidationErrMessages } from "@shared/utils";
import { Button, Form, Input, message, Select } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { createVideo } from "../videos.service";

export default function CreateModal({ onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  // antd form instance
  const [form] = Form.useForm();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const createVideoMutation = useMutation((data) => createVideo(data), {
    onSuccess: () => {
      message.success(t("Video created successfully"));
      queryClient.invalidateQueries("video");

      // Reset all form fields
      form.resetFields();
      onModalClose();
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const handleCreate = (formValues) => {
    createVideoMutation.mutate(formValues);
  };

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title="Create Video"
      onClose={!createVideoMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      onSubmit={() => {
        form.validateFields().then((values) => {
          handleCreate(values);
        });
      }}
      isSubmitting={createVideoMutation.isLoading}
    >
      <Form layout="vertical" form={form}>
        <Form.Item
          name="title"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Title")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="link"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Link")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="description"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Description")}
        >
          <Input />
        </Form.Item>
      </Form>
    </BaseModal>
  );
}
