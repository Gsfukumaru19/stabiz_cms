import { Button, Input } from "antd";
import React from "react";
import { useTranslation } from "react-i18next";

export default function SearchVideos({
  inputValues,
  onReset,
  onSearch,
  onSearchInputChange,
  isSearchOn,
}) {
  const { t } = useTranslation();

  return (
    <>
      <div className="flex justify-between">
        <div className="w-30">
          <p>{t("Title")}</p>
          <Input
            value={inputValues?.title}
            onChange={(e) => onSearchInputChange("title", e.target.value)}
          />
        </div>
        <div className="w-30">
          <p>{t("Link")}</p>
          <Input
            value={inputValues?.link}
            onChange={(e) => onSearchInputChange("link", e.target.value)}
          />
        </div>
        <div className="w-30">
          <p>{t("Description")}</p>
          <Input
            value={inputValues?.description}
            onChange={(e) => onSearchInputChange("description", e.target.value)}
          />
        </div>
      </div>
      <div className="mt-1">
        <Button type="primary" onClick={onSearch}>
          {isSearchOn ? "Search again" : "Search"}
        </Button>
        {isSearchOn && (
          <Button className="ml-1" type="secondary" onClick={onReset}>
            Close search
          </Button>
        )}
      </div>
    </>
  );
}
