import { DeleteTwoTone, EditTwoTone, EyeTwoTone } from "@ant-design/icons";
import { BaseTable, SearchPanel, TableSkeleton } from "@shared/components";
import { Button, message, Popconfirm, Tooltip } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";

import { deleteVideo, fetchVideos } from "../videos.service";
import EditModal from "./EditModal";
import SearchVideos from "./SearchVideos";

export default function VideosTable() {
  const { t } = useTranslation();

  /* ---- Search ---- */
  const [searchParams, setSearchParams] = useState();

  const [isSearchOn, setIsSearchOn] = useState(false);
  // To close the accordion, after search is closed
  const [currCollpaseKey, setCurrCollpaseKey] = useState();

  const handleInputChange = (key, val) => {
    setSearchParams({
      ...searchParams,
      [key]: val,
    });
  };

  const toggleSearch = () => {
    setIsSearchOn(true);
  };

  const handleReset = () => {
    setCurrCollpaseKey();
    setSearchParams();
    setIsSearchOn(false);
  };

  // Store the record from table cell, convert to boolean to toggle modal open
  // Used for both edit and preview modal
  const [currentOnViewRecord, setCurrentOnViewRecord] = useState();
  const [currentModalMode, setCurrentModalMode] = useState();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const deleteVideoMutation = useMutation((data) => deleteVideo(data), {
    onSuccess: () => {
      message.success(t("Video deleted successfully"));
      queryClient.invalidateQueries("video");
    },
    onError: (error) => {
      message.error(error.statusText);
    },
  });

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    total: null,
  });

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  /* ---- Paginated query ---- */
  const videosResult = useQuery(
    [
      "video",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        ...(isSearchOn && {
          ...searchParams,
        }),
      },
    ],
    () =>
      fetchVideos({
        page: paginationCtrl.current,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        ...(isSearchOn && {
          ...searchParams,
          page: paginationCtrl.current !== 1 ? 1 : paginationCtrl.current, // TODO: write docs
        }),
      }),
    { keepPreviousData: true, staleTime: 5000, retry: false }
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (videosResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: videosResult.data?.meta.total,
      }));
    }
  }, [videosResult.data]);

  const columns = [
    {
      title: `${t("Title")}`,
      dataIndex: "title",
      key: "title",
    },
    {
      title: `${t("Link")}`,
      dataIndex: "link",
      key: "link",
      render: (link) => (
        <Button
          onClick={() => {
            window.open(link);
          }}
        >
          <EyeTwoTone />
        </Button>
      ),
    },
    {
      title: `${t("Description")}`,
      dataIndex: "description",
      key: "description",
    },
    {
      title: `${t("Edit")}`,
      key: "edit",
      dataIndex: "id",
      render: (id, record) => (
        <Tooltip placement="topLeft" title={t("Edit")}>
          <Button
            onClick={() => {
              setCurrentOnViewRecord(record);
              setCurrentModalMode("EDIT");
            }}
          >
            <EditTwoTone />
          </Button>
        </Tooltip>
      ),
    },
    {
      title: `${t("Delete")}`,
      key: "delete",
      dataIndex: "id",
      render: (id) => (
        <Popconfirm
          title={t("Are you sure?")}
          onConfirm={() => deleteVideoMutation.mutate(id)}
          okButtonProps={{
            loading: deleteVideoMutation.isLoading,
          }}
          okText={t("Ok")}
          cancelText={t("Cancel")}
        >
          <Button>
            <DeleteTwoTone twoToneColor="#ff4d4f" />
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <>
      {currentModalMode === "EDIT" && (
        <EditModal
          currData={currentOnViewRecord}
          onModalClose={() => setCurrentOnViewRecord(null)}
          isModalVisible={!!currentOnViewRecord}
        />
      )}
      <div className="mb-1">
        <SearchPanel
          onReset={handleReset}
          onSearch={toggleSearch}
          isSearchOn={isSearchOn}
          inputValues={searchParams}
          onSearchInputChange={handleInputChange}
          searchComponent={SearchVideos}
          currCollpaseKey={currCollpaseKey}
          setCurrCollpaseKey={setCurrCollpaseKey}
        />
      </div>

      {videosResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <BaseTable
          columns={columns}
          data={videosResult.data?.data}
          paginationCtrl={paginationCtrl}
          onPageChange={handlePageChange}
        />
      )}
    </>
  );
}
