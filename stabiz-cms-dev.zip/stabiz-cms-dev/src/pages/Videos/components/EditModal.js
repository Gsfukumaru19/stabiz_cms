import { BaseModal } from "@shared/components";
import { createValidationErrMessages, diffBetweenObjects } from "@shared/utils";
import { Button, Divider, Form, Input, message, Select } from "antd";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { updateVideo } from "../videos.service";

export default function EditModal({ currData, onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  // antd form instance
  const [form] = Form.useForm();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const updateVideoMutation = useMutation((data) => updateVideo(data), {
    onSuccess: () => {
      message.success(t("Video updated successfully"));
      queryClient.invalidateQueries("video");

      onModalClose();
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title="Update Video"
      onClose={!updateVideoMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      footer={null}
    >
      <Form
        layout="vertical"
        form={form}
        initialValues={currData} // Fill in with current values
        onFinish={() =>
          form.validateFields().then((values) => {
            const diffValues = diffBetweenObjects(currData, values);
            updateVideoMutation.mutate({ id: currData.id, body: diffValues });
          })
        }
      >
        <Form.Item
          name="title"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Title")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="link"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Link")}
        >
          <Input />
        </Form.Item>

        <Form.Item
          name="description"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Description")}
        >
          <Input />
        </Form.Item>

        <Form.Item>
          <Button
            loading={updateVideoMutation.isLoading}
            disabled={updateVideoMutation.isLoading}
            type="primary"
            htmlType="submit"
          >
            {t("Update")}
          </Button>
        </Form.Item>
      </Form>
    </BaseModal>
  );
}
