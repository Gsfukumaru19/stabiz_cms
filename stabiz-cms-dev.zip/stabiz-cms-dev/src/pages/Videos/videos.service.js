import { handleMutation, handleQuery } from "@shared/services/api-client";

export const fetchVideos = async (queryParams) =>
  handleQuery({ resourceUrl: `/videos`, queryParams });

export const createVideo = async (reqBody) =>
  handleMutation({ method: "POST", resourceUrl: `/videos`, reqBody });

export const updateVideo = async (reqBody) =>
  handleMutation({
    method: "PATCH",
    resourceUrl: `/videos/${reqBody.id}`,
    reqBody: reqBody.body,
  });

export const deleteVideo = async (id) =>
  handleMutation({ method: "DELETE", resourceUrl: `/videos/${id}` });
