import { CreateButton, PaddedLayout } from "@shared/components";
import { useState } from "react";
import { useTranslation } from "react-i18next";

import CreateModal from "./components/CreateModal";
import NewsTopicsTable from "./components/NewsTopicsTable";

export default function NewsTopics() {
  const { t } = useTranslation();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const toggleModalOpen = (val) => setIsCreateModalOpen(val);

  return (
    <>
      <CreateModal
        isModalVisible={isCreateModalOpen}
        onModalClose={() => toggleModalOpen(false)}
      />
      <PaddedLayout>
        <div>
          <div className="flex flex-row-reverse">
            <CreateButton
              onClick={() => toggleModalOpen(true)}
              buttonText={t("Create News and Topics")}
            />
          </div>
          <NewsTopicsTable />
        </div>
      </PaddedLayout>
    </>
  );
}
