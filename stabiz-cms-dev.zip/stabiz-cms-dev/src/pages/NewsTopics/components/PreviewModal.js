import { BaseModal } from "@shared/components";
import { Divider } from "antd";
import { useTranslation } from "react-i18next";

export default function PreviewModal({ topic, onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title={null}
      onClose={onModalClose}
      isVisible={isModalVisible}
      submitButtonProps={{ disabled: true, style: { display: "none" } }}
    >
      <div style={{ marginBottom: "4rem" }}>
        <Divider orientation="center">{t("Title")}</Divider>
        <p>{topic.title}</p>
      </div>

      <div>
        <Divider orientation="center">{t("Body")}</Divider>
        <p>{topic.body}</p>
      </div>
    </BaseModal>
  );
}
