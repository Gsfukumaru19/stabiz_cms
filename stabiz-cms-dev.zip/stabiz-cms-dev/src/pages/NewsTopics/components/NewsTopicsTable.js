import { DeleteTwoTone, EditTwoTone, EyeTwoTone } from "@ant-design/icons";
import { BaseTable, TableSkeleton } from "@shared/components";
import { Button, message, Popconfirm, Tooltip } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";

import { deleteNewsTopics, fetchNewsTopics } from "../news-topics.service";
import EditModal from "./EditModal";
import PreviewModal from "./PreviewModal";

export default function NewsTopicsTable() {
  const { t } = useTranslation();

  // Store the topic from table cell, convert to boolean to toggle modal open
  // Used for both edit and preview modal
  const [currentOnViewTopic, setCurrentOnViewTopic] = useState();
  const [currentModalMode, setCurrentModalMode] = useState();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const deleteNewsTopicsMutation = useMutation(
    (data) => deleteNewsTopics(data),
    {
      onSuccess: () => {
        message.success(t("News-topic deleted successfully"));
        queryClient.invalidateQueries("news-n-topics");
      },
      onError: (error) => {
        message.error(error.statusText);
      },
    }
  );

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    total: null,
  });

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  /* ---- Paginated query ---- */
  const newsTopicsResult = useQuery(
    [
      "news-n-topics",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
      },
    ],
    () =>
      fetchNewsTopics({
        page: paginationCtrl.current,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
      }),
    { keepPreviousData: true, staleTime: 5000, retry: false } // 5 minutes of stale time
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (newsTopicsResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: newsTopicsResult.data?.meta.total,
      }));
    }
  }, [newsTopicsResult.data]);

  /* ---- Rendered columns ---- */
  const columns = [
    {
      title: `${t("Title")}`,
      dataIndex: "title",
      key: "title",
      width: "20%",
    },
    {
      title: `${t("Body")}`,
      dataIndex: "body",
      key: "body",
      width: "50%",
      ellipsis: true,
    },
    {
      title: `${t("View")}`,
      key: "view",
      dataIndex: "id",
      render: (id, record) => (
        <Tooltip placement="topLeft" title={t("View")}>
          <Button
            onClick={() => {
              setCurrentOnViewTopic(record);
              setCurrentModalMode("VIEW");
            }}
          >
            <EyeTwoTone twoToneColor="#1da57a" />
          </Button>
        </Tooltip>
      ),
    },
    {
      title: `${t("Edit")}`,
      key: "edit",
      dataIndex: "id",
      render: (id, record) => (
        // <Link to="/staffs">
        <Tooltip placement="topLeft" title={t("Edit")}>
          <Button
            onClick={() => {
              setCurrentOnViewTopic(record);
              setCurrentModalMode("EDIT");
            }}
          >
            <EditTwoTone />
          </Button>
        </Tooltip>
        // </Link>
      ),
    },
    {
      title: `${t("Delete")}`,
      key: "delete",
      dataIndex: "id",
      render: (id) => (
        <Popconfirm
          title={t("Are you sure?")}
          onConfirm={() => deleteNewsTopicsMutation.mutate(id)}
          okButtonProps={{
            loading: deleteNewsTopicsMutation.isLoading,
          }}
          okText={t("Ok")}
          cancelText={t("Cancel")}
        >
          <Button>
            <DeleteTwoTone twoToneColor="#ff4d4f" />
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <>
      {currentModalMode === "EDIT" && (
        <EditModal
          topic={currentOnViewTopic}
          onModalClose={() => setCurrentOnViewTopic(null)}
          isModalVisible={!!currentOnViewTopic}
        />
      )}
      {currentModalMode === "VIEW" && (
        <PreviewModal
          topic={currentOnViewTopic}
          onModalClose={() => setCurrentOnViewTopic(null)}
          isModalVisible={!!currentOnViewTopic}
        />
      )}
      {newsTopicsResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <BaseTable
          columns={columns}
          data={newsTopicsResult.data?.data}
          paginationCtrl={paginationCtrl}
          onPageChange={handlePageChange}
        />
      )}
    </>
  );
}
