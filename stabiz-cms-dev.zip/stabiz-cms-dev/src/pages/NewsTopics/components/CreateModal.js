import { BaseModal } from "@shared/components";
import { Input, message } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { createNewsTopics } from "../news-topics.service";

export default function CreateModal({ onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  const [title, setTitle] = useState();
  console.log("file: CreateModal.js ~ line 13 ~ CreateModal ~ title", title);
  const [body, setBody] = useState();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const createNewsTopicsMutation = useMutation(
    (data) => createNewsTopics(data),
    {
      onSuccess: () => {
        message.success(t("News-topic created successfully"));
        queryClient.invalidateQueries("news-n-topics");
        onModalClose();
      },
      onError: (error) => {
        message.error(error.statusText);
      },
    }
  );

  const handleCreateNewsTopics = () => {
    createNewsTopicsMutation.mutate({ title, body });
  };

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title={t("Create News and Topics")}
      onClose={!createNewsTopicsMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      onSubmit={handleCreateNewsTopics}
      isSubmitting={createNewsTopicsMutation.isLoading}
      submitButtonProps={{ disabled: !title || !body }} // If no title or body entered, keep the submit button disabled
    >
      <p className="m-bottom-half">{t("Title")}</p>
      <Input
        placeholder={t("Title")}
        style={{ marginBottom: "2rem" }}
        onChange={(e) => {
          setTitle(e.target.value);
        }}
      />

      <p className="m-bottom-half">{t("Body")}</p>
      <Input.TextArea
        rows={10}
        placeholder={t("Body")}
        onChange={(e) => {
          setBody(e.target.value);
        }}
      />
    </BaseModal>
  );
}
