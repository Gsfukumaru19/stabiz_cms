import { BaseModal } from "@shared/components";
import { Input, message } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { updateNewsTopics } from "../news-topics.service";

export default function EditModal({ topic, onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  const [title, setTitle] = useState();
  const [body, setBody] = useState();

  useEffect(() => {
    setTitle(topic?.title);
    setBody(topic?.body);
  }, [topic?.title, topic?.body]);

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const updateNewsTopicsMutation = useMutation(
    (data) => updateNewsTopics(data),
    {
      onSuccess: () => {
        message.success(t("News-topic updated successfully"));
        queryClient.invalidateQueries("news-n-topics");
        onModalClose();
      },
      onError: (error) => {
        message.error(error.statusText);
        onModalClose();
      },
    }
  );

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title={t("Update News Topic")}
      onClose={!updateNewsTopicsMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      onSubmit={() =>
        updateNewsTopicsMutation.mutate({
          id: topic.id,
          body: { title, body },
        })
      }
      isSubmitting={updateNewsTopicsMutation.isLoading}
      submitButtonProps={{ disabled: !title || !body }} // If no title or body entered, keep the submit button disabled
    >
      <p className="m-bottom-half">{t("Title")}</p>
      <Input
        placeholder={t("Title")}
        style={{ marginBottom: "2rem" }}
        onChange={(e) => {
          setTitle(e.target.value);
        }}
        value={title}
      />

      <p className="m-bottom-half">{t("Body")}</p>
      <Input.TextArea
        rows={10}
        placeholder={t("Body")}
        onChange={(e) => {
          setBody(e.target.value);
        }}
        value={body}
      />
    </BaseModal>
  );
}
