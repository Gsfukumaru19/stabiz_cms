import { handleMutation, handleQuery } from "@shared/services/api-client";

export const fetchNewsTopics = async (queryParams) =>
  handleQuery({ resourceUrl: `/news-n-topics`, queryParams });

export const createNewsTopics = async (reqBody) =>
  handleMutation({ method: "POST", resourceUrl: `/news-n-topics`, reqBody });

export const updateNewsTopics = async (reqBody) =>
  handleMutation({
    method: "PUT",
    resourceUrl: `/news-n-topics/${reqBody.id}`,
    reqBody: reqBody.body,
  });

export const deleteNewsTopics = async (id) =>
  handleMutation({ method: "DELETE", resourceUrl: `/news-n-topics/${id}` });
