import { PaddedLayout } from "@shared/components";
import { Col, Row } from "antd";

import SalesCard from "./components/SalesCard";
import SalesChart from "./components/SalesChart";

export default function Sales() {
  return (
    <PaddedLayout>
      <div>
        <Row gutter={16}>
          <Col span={8}>
            <SalesCard />
          </Col>
          <Col span={8}>
            <SalesCard />
          </Col>
          <Col span={8}>
            <SalesCard />
          </Col>
        </Row>
        <div style={{ marginTop: "2rem" }}>
          <SalesChart />
        </div>
      </div>
    </PaddedLayout>
  );
}
