import { PaddedLayout, SearchInput } from "@shared/components";

import EntTable from "./components/EntTable";

export default function Entrepreneurs() {
  return (
    <PaddedLayout>
      <div>
        {/* <div style={{ width: "20rem", marginBottom: "2rem" }}>
          <SearchInput placeholder="Search entrepreneurs" />
        </div> */}
        <EntTable />
      </div>
    </PaddedLayout>
  );
}
