import { Button, Input } from "antd";
import { useTranslation } from "react-i18next";

export default function SearchEnt({
  inputValues,
  onReset,
  onSearch,
  onSearchInputChange,
  isSearchOn,
}) {
  const { t } = useTranslation();

  return (
    <>
      <div className="flex justify-between">
        <div className="w-40">
          <p>{t("Last name")}</p>
          <Input
            value={inputValues?.last_name}
            onChange={(e) => onSearchInputChange("last_name", e.target.value)}
          />
        </div>
        <div className="w-40">
          <p>{t("First name")}</p>
          <Input
            value={inputValues?.first_name}
            onChange={(e) => onSearchInputChange("first_name", e.target.value)}
          />
        </div>
      </div>
      <div className="mt-1">
        <Button type="primary" onClick={onSearch}>
          {isSearchOn ? t("Search again") : t("Search")}
        </Button>
        {isSearchOn && (
          <Button className="ml-1" type="secondary" onClick={onReset}>
            {t("Close search")}
          </Button>
        )}
      </div>
    </>
  );
}
