import {
  CheckCircleFilled,
  DeleteTwoTone,
  EditTwoTone,
  EyeOutlined,
} from "@ant-design/icons";
import { BaseTable, SearchPanel, TableSkeleton } from "@shared/components";
import { deleteUser } from "@shared/services";
import { Button, message, Popconfirm } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { Link } from "react-router-dom";

import { fetchAssignUsers, fetchEntrepreneurs } from "../entrepreneurs.service";
import AssignModal from "./AssignModal";
import SearchEnt from "./SearchEnt";

export default function EntTable() {
  const { t } = useTranslation();

  /* ---- Search ---- */
  // TODO: Write search panel mechanism docs
  const [searchParams, setSearchParams] = useState();

  const [isSearchOn, setIsSearchOn] = useState(false);

  const [currCollpaseKey, setCurrCollpaseKey] = useState();

  const [userId, setUserId] = useState("");

  const handleInputChange = (key, val) => {
    setSearchParams({
      ...searchParams,
      [key]: val,
    });
  };

  const toggleSearch = () => setIsSearchOn(true);

  const handleReset = () => {
    setCurrCollpaseKey();
    setSearchParams();
    setIsSearchOn(false);
  };

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    current: 1,
    total: null,
  });

  /* ---- Assignment Modal ---- */
  const [showModal, setShowModal] = useState(false);
  const [ModalData, setModalData] = useState(null);
  const [Column, setColumn] = useState(null);

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  // Close the Assign modal
  const setHideModal = (param) => {
    setShowModal(false);
    if (param === 2) {
      entrepreneursResult.refetch();
    }
  };

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const deleteUserMutation = useMutation((data) => deleteUser(data), {
    onSuccess: () => {
      message.success(t("User deleted successfully"));
      queryClient.invalidateQueries("entrepreneurs");
    },
    onError: (error) => {
      message.error(error.statusText);
    },
  });

  /* ---- Paginated query ---- */
  const entrepreneursResult = useQuery(
    [
      "entrepreneurs",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        add_assigned_staff: 1,
        ...(isSearchOn && { ...searchParams }),
      },
    ],
    () =>
      fetchEntrepreneurs({
        page: paginationCtrl.current,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        add_assigned_staff: 1,
        ...(isSearchOn && { ...searchParams }),
      }),
    { keepPreviousData: true, staleTime: 5000, retry: false }
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (entrepreneursResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: entrepreneursResult.data?.meta.total,
      }));
    }
  }, [entrepreneursResult.data]);

  const columns = [
    {
      title: `${t("Email Verified")}`,
      dataIndex: "email_verified_at",
      key: "email_verified_at",
      width: "6%",
      render: (emailVerifiedAt) => (
        <>
          {emailVerifiedAt ? (
            <CheckCircleFilled
              style={{ color: "#52c41a", fontSize: "1.25rem" }}
            />
          ) : null}
        </>
      ),
    },
    {
      title: `${t("Name")}`,
      dataIndex: "name",
      key: "name",
      width: "10%",
      render: (id, record) => (
        <p>
          {record?.last_name} {record?.first_name}
        </p>
      ),
    },
    {
      title: `${t("Email")}`,
      dataIndex: "email",
      key: "email",
      width: "30%",
    },
    {
      title: `${t("Age")}`,
      dataIndex: "age",
      key: "age",
      width: "5%",
    },
    {
      title: `${t("Assign")}`,
      dataIndex: "assign",
      key: "assign",
      headerAlign: "center",
      align: "center",
      width: "4%",
      // render: (id, record) => <p>{record?.address}</p>,
      render: (id, record) => (
        <Button
          onClick={async () => {
            const assignedArrayData = [];
            // const { data: assignedStaff } = await fetchAssignUsers({
            //   user_id: record.id,
            // });

            // // console.log(record);
            setUserId(record.id);

            const assignedArray = record.assigned_staff.map((v) => {
              return {
                id: v.staff.id,
                name: `${v.staff.last_name} ${v.staff.first_name}`,
              };
            });

            if (assignedArray) {
              setModalData(null);
              assignedArray.map((assign) => {
                assignedArrayData.push(assign);
              });
              const AssignedTableData = [];
              const AssignedTableColumn = [
                { dataField: "id", text: "id", hidden: true },
                {
                  dataField: "name",
                  text: "name",
                },
              ];

              assignedArrayData.map((assigned) =>
                AssignedTableData.push({
                  name: assigned.name,
                  id: assigned.id,
                })
              );

              setColumn(AssignedTableColumn);
              setModalData(AssignedTableData);
              setShowModal(true);
            } else {
              const AssignedTableData = [];
              setModalData(null);
              const AssignedTableColumn = [
                { dataField: "id", text: "id", hidden: true },
                {
                  dataField: "name",
                  text: "name",
                },
              ];
              assignedArrayData.map((assigned) =>
                AssignedTableData.push({
                  name: assigned.name,
                  id: assigned.id,
                })
              );

              setColumn(AssignedTableColumn);
              setModalData(AssignedTableData);
              setShowModal(true);
            }
          }}
        >
          <EyeOutlined />
        </Button>
      ),
    },
    {
      title: `${t("Assigned Staff")}`,
      key: "id",
      dataIndex: "id",
      // width: "10%",
      render: (id, record) => {
        let assignedStaffNames = [];

        assignedStaffNames = record.assigned_staff.map(
          (v) => `${v.staff.last_name} ${v.staff.first_name}`
        );

        return <p>{assignedStaffNames.join(",  ")}</p>;
      },
    },
    // {
    //   title: `${t("Income range")}`,
    //   dataIndex: "incomeRange",
    //   key: "incomeRange",
    // },
    {
      title: `${t("Details")}`,
      key: "id",
      dataIndex: "id",
      width: "10%",
      render: (id) => (
        <Link to={`/entrepreneur/${id}`}>
          <Button>{t("View profile details")}</Button>
        </Link>
      ),
    },
    {
      title: `${t("Delete")}`,
      key: "delete",
      dataIndex: "id",
      render: (id) => (
        <Popconfirm
          title={t("Are you sure?")}
          onConfirm={() => deleteUserMutation.mutate(id)}
          okButtonProps={{
            loading: deleteUserMutation.isLoading,
          }}
          okText={t("Ok")}
          cancelText={t("Cancel")}
        >
          <Button>
            <DeleteTwoTone twoToneColor="#ff4d4f" />
          </Button>
        </Popconfirm>
      ),
    },
  ];

  // console.log(ModalData);

  return (
    <>
      {showModal && (
        <AssignModal
          data={ModalData}
          showModal={showModal}
          columns={Column}
          hideModal={(param) => setHideModal(param)}
          userId={userId}
          // onSubmit={onSupplierSelectedList}
          // loading={Loader}
        />
      )}
      <div className="mb-1">
        <SearchPanel
          onReset={handleReset}
          onSearch={toggleSearch}
          isSearchOn={isSearchOn}
          inputValues={searchParams}
          onSearchInputChange={handleInputChange}
          searchComponent={SearchEnt}
          currCollpaseKey={currCollpaseKey}
          setCurrCollpaseKey={setCurrCollpaseKey}
        />
      </div>
      {entrepreneursResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <BaseTable
          columns={columns}
          data={entrepreneursResult.data?.data}
          paginationCtrl={paginationCtrl}
          onPageChange={handlePageChange}
        />
      )}
    </>
  );
}
