import { BaseModal } from "@shared/components";
import { Button, Select } from "antd";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";

import { fetchStaffs, postAssign } from "../entrepreneurs.service";

const { Option } = Select;

export default function AssignModal({
  data,
  showModal,
  userId,
  columns,
  hideModal,
  onSubmit,
  loading,
}) {
  const { t } = useTranslation();
  const [Data, setData] = useState(null);
  const [newData, setNewData] = useState(null);
  const [StaffList, setStaffList] = useState(null);

  function handleChange(value) {
    console.log(`Selected: ${value}`);
    // console.log(value);
    setNewData(value);

    // console.log(arr[0]);
  }

  const handleUpdate = async (e) => {
    e.preventDefault();
    const arr = [];
    console.log("click");
    arr.push(parseInt(userId.toString()));

    // console.log(userId);

    setData(newData);

    for (let i = 0; i < newData.length; i++) {
      console.log("running...");
      await postAssign({
        user_id: arr,
        staff_id: parseInt(newData[i]),
      });
      // console.log(staffsResult);
    }
    hideModal(2);
  };

  // console.log(Data);
  // console.log(userId);

  useEffect(async () => {
    const staffsResult = await fetchStaffs();

    const tempArray = [];
    if (staffsResult.data.length) {
      staffsResult.data.map((item) => {
        const { id, first_name, last_name } = item;
        tempArray.push({ id, name: `${last_name} ${first_name}` });
      });
    }
    setStaffList(tempArray);
  }, []);

  useEffect(() => {
    const asd = data.map((d) => d.id.toString());
    setData(asd);
    // console.log(asd);
    return () => setData(null);
  }, []);

  return (
    <div>
      {Data && StaffList && (
        <BaseModal
          title={t("Assign")}
          onClose={() => hideModal(1)}
          isVisible={showModal}
          footer={null}
        >
          <Select
            mode="multiple"
            size="large"
            placeholder={t("Please select")}
            defaultValue={Data}
            onChange={handleChange}
            style={{ width: "100%" }}
          >
            {StaffList.map((staff) => (
              <Option key={staff.id}>{staff.name}</Option>
            ))}
          </Select>
          <br />
          <br />
          <Button type="primary" htmlType="submit" onClick={handleUpdate}>
            {t("Submit")}
          </Button>
        </BaseModal>
      )}
    </div>
  );
}
