import { PaddedLayout } from "@shared/components";
import { Col, Row } from "antd";
import { useEffect, useState } from "react";

import NewsCard from "./components/NewsCard";

export default function ArticlesBlogs() {
  // ! TEMP: workaround for loading
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  return (
    <PaddedLayout>
      <div>
        <Row gutter={[24, 40]}>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
          <Col span={6}>
            <NewsCard isLoading={isLoading} />
          </Col>
        </Row>
      </div>
    </PaddedLayout>
  );
}
