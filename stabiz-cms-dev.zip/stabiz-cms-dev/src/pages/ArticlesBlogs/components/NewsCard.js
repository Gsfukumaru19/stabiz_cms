import { Card } from "antd";

const { Meta } = Card;

export default function NewsCard({ isLoading }) {
  return (
    <Card
      loading={isLoading}
      hoverable
      size="small"
      // bodyStyle={{ minHeight: "12rem" }}
      cover={
        <img
          alt="example"
          src="http://lorempixel.com/640/640/business/"
          style={{ minHeight: "10rem" }}
        />
      }
    >
      <Meta
        title="Article Title"
        description="Molestias optio repellendus fugit. Sed reiciendis adipisci mollitia quia velit a sit. Vel vel incidunt quibusdam est..."
      />
    </Card>
  );
}
