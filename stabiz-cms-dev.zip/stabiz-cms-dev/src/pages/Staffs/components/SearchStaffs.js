import { Button, Input } from "antd";
import { useTranslation } from "react-i18next";

export default function SearchStaffs({
  inputValues,
  onReset,
  onSearch,
  onSearchInputChange,
  isSearchOn,
}) {
  const { t } = useTranslation();

  return (
    <>
      <div className="flex justify-between">
        <div className="w-30">
          <p>{t("First name")}</p>
          <Input
            value={inputValues?.first_name}
            onChange={(e) => onSearchInputChange("first_name", e.target.value)}
          />
        </div>
        <div className="w-30">
          <p>{t("Last name")}</p>
          <Input
            value={inputValues?.last_name}
            onChange={(e) => onSearchInputChange("last_name", e.target.value)}
          />
        </div>
        <div className="w-30">
          <p>{t("Email")}</p>
          <Input
            value={inputValues?.email}
            onChange={(e) => onSearchInputChange("email", e.target.value)}
          />
        </div>
      </div>
      <div className="mt-1">
        <Button type="primary" onClick={onSearch}>
          {isSearchOn ? "Search again" : "Search"}
        </Button>
        {isSearchOn && (
          <Button className="ml-1" type="secondary" onClick={onReset}>
            Close search
          </Button>
        )}
      </div>
    </>
  );
}
