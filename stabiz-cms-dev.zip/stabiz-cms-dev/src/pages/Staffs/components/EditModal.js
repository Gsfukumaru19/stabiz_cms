import { BaseModal } from "@shared/components";
import { createValidationErrMessages, diffBetweenObjects } from "@shared/utils";
import { Button, Divider, Form, Input, message, Select } from "antd";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { updateStaff, updateStaffPassword } from "../staffs.service";

export default function EditModal({ currData, onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  // antd form instance
  const [form] = Form.useForm();
  const [passwordForm] = Form.useForm();

  /**
   * Set default form values,
   * only changed values are passed, on finish
   */
  useEffect(() => {
    form.setFieldsValue({ ...currData, role: currData?.roles[0].name });
  }, [form, currData]);

  useEffect(() => {
    passwordForm.setFieldsValue();
  }, []);

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const updateStaffMutation = useMutation((data) => updateStaff(data), {
    onSuccess: () => {
      message.success(t("Staff updated successfully"));
      queryClient.invalidateQueries("staff");

      onModalClose();
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const updateStaffPasswordMutation = useMutation(
    (data) => updateStaffPassword(data),
    {
      onSuccess: () => {
        message.success(t("Staff password updated successfully"));
        onModalClose();
      },
      onError: (error) => {
        // Handle validation error messages from backend
        if (error.status === 422) {
          const validationErrors = createValidationErrMessages(
            error.data?.errors
          );
          validationErrors.forEach((msg) => message.error(msg));
        } else {
          message.error(error?.data?.message);
        }
      },
    }
  );

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title="Update Staff"
      onClose={!updateStaffMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      footer={null}
    >
      <Form
        layout="vertical"
        form={form}
        initialValues={currData} // Fill in with current values
        onFinish={() =>
          form.validateFields().then((values) => {
            const diffValues = diffBetweenObjects(currData, values);
            updateStaffMutation.mutate({ id: currData.id, body: diffValues });
          })
        }
      >
        <div className="flex justify-between">
          <Form.Item
            name="first_name"
            rules={[{ required: true, message: `${t("required")}` }]}
            label={t("First Name")}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="last_name"
            rules={[{ required: true, message: `${t("required")}` }]}
            label={t("Last Name")}
          >
            <Input />
          </Form.Item>
        </div>
        <Form.Item
          name="email"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Email")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="phone"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Phone")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="role"
          defaulV
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Role")}
          style={{ width: "35%" }}
        >
          <Select>
            <Select.Option value="super-admin">
              {t("Super admin")}
            </Select.Option>
            <Select.Option value="matchmaker">{t("Match maker")}</Select.Option>
          </Select>
        </Form.Item>

        <Form.Item>
          <Button
            loading={updateStaffMutation.isLoading}
            disabled={updateStaffMutation.isLoading}
            type="primary"
            htmlType="submit"
          >
            {t("Update")}
          </Button>
        </Form.Item>
      </Form>

      {/* UPDATE PASSWORD */}
      <Divider orientation="center">{t("Update Password")}</Divider>
      <Form
        layout="vertical"
        form={passwordForm}
        onFinish={() =>
          passwordForm.validateFields().then((values) => {
            updateStaffPasswordMutation.mutate({
              id: currData.id,
              body: values,
            });
          })
        }
      >
        <Form.Item
          name="password"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Password")}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item
          name="confirm_password"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Confirm Password")}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item>
          <Button
            loading={updateStaffMutation.isLoading}
            disabled={updateStaffMutation.isLoading}
            type="primary"
            htmlType="submit"
          >
            {t("Update Password")}
          </Button>
        </Form.Item>
      </Form>
    </BaseModal>
  );
}
