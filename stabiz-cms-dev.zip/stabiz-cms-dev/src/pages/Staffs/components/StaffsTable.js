import { DeleteTwoTone, EditTwoTone } from "@ant-design/icons";
import { BaseTable, SearchPanel, TableSkeleton } from "@shared/components";
import { Button, message, Popconfirm, Tag, Tooltip } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery, useQueryClient } from "react-query";

import { deleteStaff, fetchStaffs } from "../staffs.service";
import EditModal from "./EditModal";
import SearchStaffs from "./SearchStaffs";

export default function StaffsTable() {
  const { t } = useTranslation();

  /* ---- Search ---- */
  const [searchParams, setSearchParams] = useState();

  const [isSearchOn, setIsSearchOn] = useState(false);
  // To close the accordion, after search is closed
  const [currCollpaseKey, setCurrCollpaseKey] = useState();

  const handleInputChange = (key, val) => {
    setSearchParams({
      ...searchParams,
      [key]: val,
    });
  };

  const toggleSearch = () => {
    setIsSearchOn(true);
  };

  const handleReset = () => {
    setCurrCollpaseKey();
    setSearchParams();
    setIsSearchOn(false);
  };

  // Store the record from table cell, convert to boolean to toggle modal open
  // Used for both edit and preview modal
  const [currentOnViewRecord, setCurrentOnViewRecord] = useState();
  const [currentModalMode, setCurrentModalMode] = useState();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const deleteStaffMutation = useMutation((data) => deleteStaff(data), {
    onSuccess: () => {
      message.success(t("Staff deleted successfully"));
      queryClient.invalidateQueries("staff");
    },
    onError: (error) => {
      message.error(error.statusText);
    },
  });

  /* ---- Pagination ---- */
  const [paginationCtrl, setPaginationCtrl] = useState({
    defaultPageSize: 10,
    total: null,
  });

  // Runs on pagesize, page number change
  const handlePageChange = (updatedPagination) => {
    setPaginationCtrl((paginationState) => ({
      ...paginationState,
      ...updatedPagination,
    }));
  };

  /* ---- Paginated query ---- */
  const staffsResult = useQuery(
    [
      "staff",
      {
        page: paginationCtrl.current || 1,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        ...(isSearchOn && {
          ...searchParams,
        }),
      },
    ],
    () =>
      fetchStaffs({
        page: paginationCtrl.current,
        per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
        ...(isSearchOn && {
          ...searchParams,
          page: paginationCtrl.current !== 1 ? 1 : paginationCtrl.current, // TODO: write docs
        }),
      }),
    { keepPreviousData: true, staleTime: 5000, retry: false }
  );

  // Store the total data count, on first api data receive
  // Used for table pagination count
  useEffect(() => {
    if (staffsResult.data) {
      setPaginationCtrl((paginationState) => ({
        ...paginationState,
        total: staffsResult.data?.meta.total,
      }));
    }
  }, [staffsResult.data]);

  const columns = [
    {
      title: `${t("Name")}`,
      dataIndex: "name",
      key: "name",
      render: (text, record) => (
        <>
          {record.last_name} {record.first_name}
        </>
      ),
    },
    {
      title: `${t("Email")}`,
      dataIndex: "email",
      key: "email",
    },
    {
      title: `${t("Phone")}`,
      dataIndex: "phone",
      key: "phone",
    },
    {
      title: `${t("Roles")}`,
      key: "roles",
      render: (text, record) =>
        record.roles.map((role) => <Tag>{role.name}</Tag>),
    },
    // {
    //   title: `${t("Permissions")}`,
    //   key: "permissions",
    //   render: (text, record) => <Button>{t("Edit Permissions")}</Button>,
    // },
    {
      title: `${t("Edit")}`,
      key: "edit",
      dataIndex: "id",
      render: (id, record) => (
        <Tooltip placement="topLeft" title={t("Edit")}>
          <Button
            onClick={() => {
              setCurrentOnViewRecord(record);
              setCurrentModalMode("EDIT");
            }}
          >
            <EditTwoTone />
          </Button>
        </Tooltip>
      ),
    },
    {
      title: `${t("Delete")}`,
      key: "delete",
      dataIndex: "id",
      render: (id) => (
        <Popconfirm
          title={t("Are you sure?")}
          onConfirm={() => deleteStaffMutation.mutate(id)}
          okButtonProps={{
            loading: deleteStaffMutation.isLoading,
          }}
          okText={t("Ok")}
          cancelText={t("Cancel")}
        >
          <Button>
            <DeleteTwoTone twoToneColor="#ff4d4f" />
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <>
      {currentModalMode === "EDIT" && (
        <EditModal
          currData={currentOnViewRecord}
          onModalClose={() => setCurrentOnViewRecord(null)}
          isModalVisible={!!currentOnViewRecord}
        />
      )}
      <div className="mb-1">
        <SearchPanel
          onReset={handleReset}
          onSearch={toggleSearch}
          isSearchOn={isSearchOn}
          inputValues={searchParams}
          onSearchInputChange={handleInputChange}
          searchComponent={SearchStaffs}
          currCollpaseKey={currCollpaseKey}
          setCurrCollpaseKey={setCurrCollpaseKey}
        />
      </div>

      {staffsResult.isLoading ? (
        <TableSkeleton columns={columns} />
      ) : (
        <BaseTable
          columns={columns}
          data={staffsResult.data?.data}
          paginationCtrl={paginationCtrl}
          onPageChange={handlePageChange}
        />
      )}
    </>
  );
}
