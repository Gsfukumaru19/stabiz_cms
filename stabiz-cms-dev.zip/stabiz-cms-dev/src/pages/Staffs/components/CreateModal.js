import { BaseModal } from "@shared/components";
import { createValidationErrMessages } from "@shared/utils";
import { Button, Form, Input, message, Select } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQueryClient } from "react-query";

import { createStaff } from "../staffs.service";

export default function CreateModal({ onModalClose, isModalVisible }) {
  const { t } = useTranslation();

  // antd form instance
  const [form] = Form.useForm();

  // query client instance to invalidate query on mutation success
  const queryClient = useQueryClient();

  const createStaffMutation = useMutation((data) => createStaff(data), {
    onSuccess: () => {
      message.success(t("Staff created successfully"));
      queryClient.invalidateQueries("staff");

      // Reset all form fields
      form.resetFields();
      onModalClose();
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const handleCreate = (formValues) => {
    createStaffMutation.mutate(formValues);
  };

  if (!isModalVisible) {
    return null;
  }

  return (
    <BaseModal
      title="Create Staff"
      onClose={!createStaffMutation.isLoading && onModalClose} // Don't let close modal, while mutation is running
      isVisible={isModalVisible}
      onSubmit={() => {
        form.validateFields().then((values) => {
          handleCreate(values);
        });
      }}
      isSubmitting={createStaffMutation.isLoading}
    >
      <Form layout="vertical" form={form}>
        <Form.Item
          name="first_name"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("First Name")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="last_name"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Last Name")}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="email"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Email")}
        >
          <Input />
        </Form.Item>
        <div className="flex justify-between">
          <Form.Item
            name="phone"
            rules={[{ required: true, message: `${t("required")}` }]}
            label={t("Phone")}
            style={{ width: "55%" }}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="role"
            rules={[{ required: true, message: `${t("required")}` }]}
            label={t("Role")}
            style={{ width: "35%" }}
          >
            <Select>
              <Select.Option value="super-admin">
                {t("Super admin")}
              </Select.Option>
              <Select.Option value="matchmaker">
                {t("Match maker")}
              </Select.Option>
            </Select>
          </Form.Item>
        </div>
        <Form.Item
          name="password"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Password")}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item
          name="confirm_password"
          rules={[{ required: true, message: `${t("required")}` }]}
          label={t("Confirm Password")}
        >
          <Input.Password />
        </Form.Item>
      </Form>
    </BaseModal>
  );
}
