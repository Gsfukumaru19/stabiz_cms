import { handleMutation, handleQuery } from "@shared/services/api-client";

export const fetchStaffs = async (queryParams) =>
  handleQuery({ resourceUrl: `/staff`, queryParams });

export const createStaff = async (reqBody) =>
  handleMutation({ method: "POST", resourceUrl: `/staff`, reqBody });

export const updateStaff = async (reqBody) =>
  handleMutation({
    method: "PATCH",
    resourceUrl: `/staff/${reqBody.id}`,
    reqBody: reqBody.body,
  });

export const updateStaffPassword = async (reqBody) =>
  handleMutation({
    method: "PATCH",
    resourceUrl: `/staff/password/${reqBody.id}`,
    reqBody: reqBody.body,
  });

export const deleteStaff = async (id) =>
  handleMutation({ method: "DELETE", resourceUrl: `/staff/${id}` });
