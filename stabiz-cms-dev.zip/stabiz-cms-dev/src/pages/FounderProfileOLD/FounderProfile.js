import { Col, Row } from "antd";

import DetailsContainer from "./components/DetailsContainer";
import LeftContainer from "./components/LeftContainer";

export default function FounderProfile() {
  return (
    <div>
      <Row gutter={0}>
        <Col span={8}>
          <LeftContainer />
        </Col>
        <Col span={16}>
          <DetailsContainer />
        </Col>
      </Row>
    </div>
  );
}
