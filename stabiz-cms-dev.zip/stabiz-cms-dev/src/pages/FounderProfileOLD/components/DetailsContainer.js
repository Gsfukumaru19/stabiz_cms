import { FundOutlined, UserOutlined } from "@ant-design/icons";
import { SalesChart } from "@shared/components";
import { Content, Layout, Tabs } from "antd";
import { useTranslation } from "react-i18next";

const { TabPane } = Tabs;

export default function DetailsContainer() {
  const { t } = useTranslation();

  return (
    <Layout
      style={{
        minHeight: "108%",
        marginTop: "-32px",
        marginBottom: "-24px",
      }}
    >
      <Layout.Content
        style={{
          margin: "1.5rem 1rem",
          padding: 24,
          background: "#fff",
          minHeight: "280px",
          borderRadius: "4px",
        }}
      >
        <div>
          <Tabs>
            <TabPane
              tab={
                <span>
                  <UserOutlined />
                  {t("User Details")}
                </span>
              }
              key="1"
            >
              <UserDetails />
            </TabPane>
            <TabPane
              tab={
                <span>
                  <FundOutlined />
                  {t("Sales")}
                </span>
              }
              key="2"
            >
              <UserSales />
            </TabPane>
          </Tabs>
        </div>
      </Layout.Content>
    </Layout>
  );
}

function UserDetails() {
  return <div>All the user details goes here</div>;
}

function UserSales() {
  return (
    <div>
      <p style={{ marginBottom: "2rem" }}>User sale statistics</p>
      <SalesChart />
    </div>
  );
}
