import { Avatar, Divider, Layout } from "antd";

import SpiderChart from "./SpiderChart";
import styles from "./styles.module.scss";

export default function LeftContainer() {
  return (
    <Layout
      style={{
        minHeight: "90vh",
        marginTop: "-32px",
        marginBottom: "-32px",
      }}
    >
      <Layout.Content
        style={{
          margin: "1.5rem 1rem",
          padding: 24,
          paddingTop: 32,
          paddingBottom: 56,
          background: "#fff",
          minHeight: "280px",
          borderRadius: "4px",
        }}
      >
        <div className="flex flex-col items-center">
          <Avatar size={160} src="http://lorempixel.com/640/640/business/" />
          <h2 className={styles.name}>Shinchan Nohara</h2>
          <h3 className={styles.subText}>Engineering Manager</h3>
          <Divider />
          <div className={styles.scoreTabs}>
            <ScoreTab title="Diagnosis Score" value="900" />
            <ScoreTab title="Rated Score" value="755" />
          </div>
          <Divider />
          <p style={{ marginBottom: "1rem" }}>Matched Data</p>
          <SpiderChart />
        </div>
      </Layout.Content>
    </Layout>
  );
}

function ScoreTab({ title, value }) {
  return (
    <div className={styles.scoreTab}>
      <p>{title}</p>
      <h2>{value}</h2>
    </div>
  );
}
