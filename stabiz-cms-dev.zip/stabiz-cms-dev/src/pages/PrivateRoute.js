import { TopProgressBar } from "@shared/components";
import { useAuthUser } from "@shared/contexts/auth-user.context";
import { fetchAuthUser } from "@shared/services";
import { message } from "antd";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "react-query";
import { Redirect } from "react-router-dom";

/**
 * User authentication check
 * Token validation check, all will be done here
 * Private route will act as the orchestrator
 */
export default function PrivateRoute({ path, component }) {
  const { t } = useTranslation();

  const { isLoading, error, data } = useQuery(
    "authUser",
    () => fetchAuthUser(),
    {
      retry: false, // Will not retry failed requests
    }
  );

  const { _, setAuthUser } = useAuthUser();

  useEffect(() => {
    if (!isLoading && data) {
      setAuthUser(data?.data);
    }
  }, [isLoading, data, setAuthUser]);

  if (isLoading) {
    return <TopProgressBar />;
  }

  if (error) {
    return <Redirect to="/login" />;
  }

  const Component = component;
  return <Component path={path} />;
}
