import { BaseLayout, TopProgressBar } from "@shared/components";
import { Layout } from "antd";
import { lazy, Suspense } from "react";
import { Redirect, Route, Switch } from "react-router-dom";

/* ---- Lazy loaded routes ---- */
const Entrepreneurs = lazy(() => import("pages/Entrepreneurs/Entrepreneurs"));
const EntrepreneurProfile = lazy(() =>
  import("pages/EntrepreneurProfile/EntrepreneurProfile")
);
const Founders = lazy(() => import("pages/Founders/Founders"));
const FounderProfile = lazy(() =>
  import("pages/FounderProfile/FounderProfile")
);
const Staffs = lazy(() => import("pages/Staffs/Staffs"));
const ArticlesBlogs = lazy(() => import("pages/ArticlesBlogs/ArticlesBlogs"));
const Sales = lazy(() => import("pages/Sales/Sales"));
const Videos = lazy(() => import("pages/Videos/Videos"));
const Diagnosis = lazy(() => import("pages/Diagnosis/Diagnosis"));
const NewsTopics = lazy(() => import("pages/NewsTopics/NewsTopics"));

const { Content } = Layout;

/*
* Layout of the AuthenticatedApp
+----+-+---+------+-----+
|side|+|top|header|+++++|
|bar |++---+------+-----+
|    ||all route-pages  |
|    ||renders in this  |
|    ||container        |
|    ||                 |
|    ||                 |
|    ||                 |
|    ||                 |
+----++-----------------+
 */

export default function AuthenticatedApp() {
  return (
    <BaseLayout>
      <Layout>
        <Content
          style={{
            margin: "1.5rem 1rem",
            padding: 24,
            paddingRight: 0,
            paddingLeft: 0,
            background: "#fff",
          }}
        >
          <Suspense fallback={<TopProgressBar />}>
            <Switch>
              <Redirect exact from="/" to="/entrepreneurs" />
              <Route exact path="/entrepreneurs" component={Entrepreneurs} />
              <Route
                exact
                path="/entrepreneur/:userId"
                component={EntrepreneurProfile}
              />
              <Route exact path="/founders" component={Founders} />
              <Route exact path="/founder/:userId" component={FounderProfile} />
              <Route exact path="/staffs" component={Staffs} />
              <Route exact path="/articles-blogs" component={ArticlesBlogs} />
              <Route exact path="/sales" component={Sales} />
              <Route exact path="/videos" component={Videos} />
              <Route exact path="/diagnosis" component={Diagnosis} />
              <Route exact path="/news-topics" component={NewsTopics} />
            </Switch>
          </Suspense>
        </Content>
      </Layout>
    </BaseLayout>
  );
}
