import clsx from "clsx";

import LoginForm from "./LoginForm";
import styles from "./styles.module.scss";

export default function Login() {
  return (
    <div
      className={clsx(
        "minh-100 flex justify-center items-center",
        styles.loginPageContainer
      )}
    >
      <LoginForm />
    </div>
  );
}
