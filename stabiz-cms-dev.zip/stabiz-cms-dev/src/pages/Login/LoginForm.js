import { LockOutlined, UserOutlined } from "@ant-design/icons";
import { createValidationErrMessages, setLocalToken } from "@shared/utils";
import { Button, Form, Input, message } from "antd";
import { useTranslation } from "react-i18next";
import { useMutation } from "react-query";
import { useHistory } from "react-router-dom";

import { login } from "./login.service";
import styles from "./styles.module.scss";

export default function LoginForm() {
  const { t } = useTranslation();
  const history = useHistory();

  const [form] = Form.useForm();

  const loginMutation = useMutation((data) => login(data), {
    onSuccess: (data) => {
      // Save the tokens
      setLocalToken("auth-access", data.accessToken);
      setLocalToken("auth-user", data.token.user_id);

      // Redirect to home
      history.push("/entrepreneurs");
      window.location.reload();
    },
    onError: (error) => {
      // Handle validation error messages from backend
      if (error.status === 422) {
        const validationErrors = createValidationErrMessages(
          error.data?.errors
        );

        validationErrors.forEach((msg) => message.error(msg));
      } else {
        message.error(error?.data?.message);
      }
    },
  });

  const onFinish = (values) => {
    loginMutation.mutate(values);
  };

  return (
    <>
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        className={styles.loginForm}
      >
        <h2>{t("Staff Login")}</h2>
        <Form.Item
          name="email"
          rules={[
            { required: true, message: `${t("Please enter your email")}` },
          ]}
        >
          <Input
            prefix={<UserOutlined className="site-form-item-icon" />}
            placeholder={t("Email")}
          />
        </Form.Item>
        <Form.Item
          name="password"
          rules={[
            { required: true, message: `${t("Please enter your password")}` },
          ]}
        >
          <Input.Password
            prefix={<LockOutlined className="site-form-item-icon" />}
            type="password"
            placeholder={t("Password")}
          />
        </Form.Item>
        <Form.Item>
          <Button
            loading={loginMutation.isLoading}
            disabled={loginMutation.isLoading}
            type="primary"
            htmlType="submit"
            className="login-form-button"
          >
            {t("Login")}
          </Button>
        </Form.Item>
      </Form>
    </>
  );
}
