import {
  render,
  screen,
  userEvent,
  waitFor,
} from "@shared/utils/test-utils/test-setup";

// "@shared/utils/test-utils/test-setup";
import Login from "./Login";

describe("Login Page", () => {
  it("renders", async () => {
    render(<Login />);

    screen.getByRole("button", {
      name: /login/i,
    });
  });

  it("validates required input fields", async () => {
    render(<Login />);

    userEvent.click(
      screen.getByRole("button", {
        name: /login/i,
      })
    );

    expect(
      await screen.findByText(/please enter your email/i)
    ).toBeInTheDocument();

    expect(
      await screen.findByText(/please enter your password/i)
    ).toBeInTheDocument();

    // userEvent.type(screen.getByPlaceholderText(/email/i), "valid_emailsss");

    // userEvent.click(
    //   screen.getByRole("button", {
    //     name: /login/i,
    //   })
    // );

    // await waitFor(() => {
    //   expect(screen.getByText(/please enter your email/i)).toBe(null);
    // });

    // expect(
    //   await screen.findByText(/please enter your email/i)
    // ).not.toBeInTheDocument();

    // userEvent.type(
    //   screen.getByPlaceholderText(/password/i),
    //   "valid_passwordsss"
    // );

    // userEvent.click(
    //   screen.getByRole("button", {
    //     name: /login/i,
    //   })
    // );

    // expect(
    //   await screen.findByText(/please enter your password/i)
    // ).not.toBeInTheDocument();
  });
});
