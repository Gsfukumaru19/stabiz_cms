import { handleMutation } from "@shared/services/api-client";

export const login = async (reqBody) =>
  handleMutation({ method: "POST", resourceUrl: "/login/staff", reqBody });
