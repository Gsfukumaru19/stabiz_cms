import { useQuery } from "react-query";

export const useQueryWrapper = ({
  queryKey,
  queryFn,
  queryParams,
  queryOptions = {},
  onSuccess = () => {},
  onError,
}) => {
  const queryResult = useQuery([queryKey, queryParams], () => queryFn, {
    ...queryOptions,
    onSuccess: (data) => {
      // invalidate some query
      onSuccess(data);
    },
    onError: (error) => {
      // Handle the error,
      // if error handler not passed, console log the error
      if (onError) {
        onError(error);
      } else {
        console.log("Query", queryKey, error);
      }
    },
  });
  return queryResult;
};

// const newsTopicsResult = useQueryWrapper({
//   queryKey: "news-n-topics",
//   queryFn: fetchNewsTopics({
//     page: paginationCtrl.current,
//     per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
//   }),
//   queryParams: {
//     page: paginationCtrl.current || 1,
//     per_page: paginationCtrl.pageSize || paginationCtrl.defaultPageSize,
//   },
//   queryOptions: { keepPreviousData: true, staleTime: 5000 },
// });
