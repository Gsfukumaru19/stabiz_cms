export * from "./diagnosis.service";
export * from "./mutations.service";
export * from "./queries.service";
