import { handleQuery } from "@shared/services/api-client";

export const fetchAuthUser = async () =>
  handleQuery({ resourceUrl: `/staff/authenticated` });

export const fetchUser = async (userId) =>
  handleQuery({ resourceUrl: `/users/${userId}` });
