import { handleMutation, handleQuery } from "./api-client";

/* ---- Queries ---- */
export const fetchDiagnosisUser = async (queryParams) =>
  handleQuery({
    resourceUrl: `/user/${queryParams.userId}`,
    apiService: "diagnosis",
  });

/**
 * RESULTS
 */
/**
 * :param: user_id          //"1234"
 * :param: category         //"major" or "middle" or "minor
 */
export const fetchSection1Output = async (queryParams) =>
  handleQuery({
    resourceUrl: `/section1`,
    queryParams,
    apiService: "diagnosis",
  });

/**
 * :param: user_id           //"1234"
 */
export const fetchSection2Output = async (queryParams) =>
  handleQuery({
    resourceUrl: `/section2`,
    queryParams,
    apiService: "diagnosis",
  });

/**
 * :param: user_id           //"1234"
 */
export const fetchSection3Output = async (queryParams) =>
  handleQuery({
    resourceUrl: `/section3`,
    queryParams,
    apiService: "diagnosis",
  });

/* ---- Mutations ---- */
// {user_id: ""}
export const createDiagnosisUser = async (reqBody) =>
  handleMutation({
    method: "POST",
    resourceUrl: "/user/create",
    reqBody,
    apiService: "diagnosis",
  });

/*
{
    "user_id": "",
    "answer" : "" or ["", ""]
}
 */

// {
//     "user_id" : str(user_id),
//     "section": 1 or 3,
//     "answers" : [
//         {
//             "question_number" : str(question_number),
//             "answer" : "a"
//         },
//     ]
// }
