import { handleMutation } from "@shared/services/api-client";

export const deleteUser = async (id) =>
  handleMutation({ method: "DELETE", resourceUrl: `/users/${id}` });
