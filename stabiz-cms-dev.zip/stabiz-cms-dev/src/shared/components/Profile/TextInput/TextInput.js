/* eslint-disable import/prefer-default-export */
import { Input } from "antd";
import { useTranslation } from "react-i18next";

export function TextInput({
  value,
  defaultValue,
  onChange,
  placeholder = "Enter text",
  ...restProps
}) {
  const { t } = useTranslation();
  return (
    <Input
      className="text-base mb-0"
      defaultValue={defaultValue}
      value={value}
      onChange={onChange}
      placeholder={t(placeholder)}
      {...restProps}
    />
  );
}
