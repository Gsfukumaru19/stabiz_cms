import { useTranslation } from "react-i18next";
/* eslint-disable import/prefer-default-export */
export function ProfileDetail({ heading, data }) {
  const { t } = useTranslation();
  return (
    <div className="flex border border-gray-200 border-solid">
      <div
        className="bg-gray-300 px-4 py-2 w-36 rounded-sm rounded-tr-none rounded-tl-none"
        style={{
          width: "25%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <p className="text-sm opacity-90 font-semibold mb-0  text-center">
          {t(heading)}
        </p>
      </div>
      <div className="px-4 py-2 w-100">
        <p className="text-base mb-0">{t(data) || "-"}</p>
      </div>
    </div>
  );
}
