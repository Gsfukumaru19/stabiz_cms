import "moment/locale/ja";

import { DatePicker } from "antd";
import locale from "antd/es/date-picker/locale/ja_JP";
import moment from "moment";

// eslint-disable-next-line import/prefer-default-export
export function DateInput({
  onChange,
  placeholder,
  value,
  format = "YYYY-MM-DD",
  ...restProps
}) {
  return (
    <DatePicker
      locale={locale}
      onChange={onChange}
      placeholder={placeholder}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...(value && {
        value: moment(value, format),
      })}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...restProps}
    />
  );
}
