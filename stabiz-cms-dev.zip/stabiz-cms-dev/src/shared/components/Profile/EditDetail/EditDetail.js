import { useTranslation } from "react-i18next";

// eslint-disable-next-line import/prefer-default-export
export function EditDetail({ heading, children }) {
  const { t } = useTranslation();
  return (
    <div className="flex border border-gray-200 border-solid">
      <div
        className="bg-gray-300 px-4 py-2 rounded-sm rounded-tr-none rounded-tl-none basis-4/12	 flex items-center flex-col justify-center"
        style={{
          flexBasis: "25%",
        }}
      >
        <p className="text-sm opacity-90 font-semibold mb-0 w-full text-center">
          {t(heading)}
        </p>
      </div>
      <div
        className="px-4 py-2 basis-8/12"
        style={{
          flexBasis: "75%",
        }}
      >
        {children}
      </div>
    </div>
  );
}
