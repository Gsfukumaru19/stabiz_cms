/* eslint-disable import/prefer-default-export */
import { Select } from "antd";
import { useTranslation } from "react-i18next";

const { Option } = Select;

export function SelectInput({
  options,
  mode,
  size,
  placeholder = "Please select",
  onChange,
  style,
  value,
  multiLimit,
  ...restProps
}) {
  const handleShowError = () => {
    console.log("nope");
  };

  const isMaxValues = value?.length === multiLimit;

  const { t } = useTranslation();
  return (
    <Select
      mode={mode}
      size={size}
      placeholder={t(placeholder)}
      onChange={onChange}
      value={value}
      style={{ ...style, width: "100%" }}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...(mode === "multiple" &&
        isMaxValues && {
          open: false,
          onDropdownVisibleChange: handleShowError,
        })}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...(mode === "multiple" && {
        defaultValue: value,
      })}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...restProps}
    >
      {options.map((opt) => (
        <Option value={opt?.value}>{t(opt?.label)}</Option>
      ))}
    </Select>
  );
}
