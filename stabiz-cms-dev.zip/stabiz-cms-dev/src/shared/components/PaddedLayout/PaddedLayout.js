// To add padding to the layout Content
// The padding was set to zero, to workaround the seperate container in user profile
export default function PaddedLayout({ children }) {
  return <div className="padded-layout">{children}</div>;
}
