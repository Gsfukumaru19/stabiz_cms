import { Table } from "antd";
import { useTranslation } from "react-i18next";

export default function BaseTable({
  columns,
  data,
  paginationCtrl,
  onPageChange,
}) {
  const { t } = useTranslation();

  return (
    <Table
      columns={columns}
      dataSource={data}
      pagination={{
        pageSizeOptions: [2, 10, 25, 50],
        showTotal: (total, range) =>
          `${range[0]}-${range[1]} / ${total} ${t("items")}`,
        showSizeChanger: true,
        ...paginationCtrl, // This is override default options
      }}
      onChange={onPageChange}
    />
  );
}
