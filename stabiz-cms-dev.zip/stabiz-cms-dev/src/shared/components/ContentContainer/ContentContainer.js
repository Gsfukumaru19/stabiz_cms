import cx from "clsx";

/**
 * This is to wrap the content,
 * so the background extends edge to edge
 * but the content stays within speicified width
 */
export default function ContentContainer({
  children,
  className,
  maxWidth = "max-w-7xl",
}) {
  return (
    <div className={cx("mx-auto px-1 w-full", className, maxWidth)}>
      {children}
    </div>
  );
}
