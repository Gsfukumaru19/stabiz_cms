import {
  Cell,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

const data = [
  {
    sub_cat: "Leadership and traction",
    score: 120,
    domain: [0, 150],
  },
  {
    sub_cat: "Flexibility, response power",
    score: 98,
    domain: [0, 150],
  },
  {
    sub_cat: "Relationship structure",
    score: 86,
    domain: [0, 150],
  },
  {
    sub_cat: "Customer-oriented",
    score: 99,
    domain: [0, 150],
  },
  {
    sub_cat: "Action based on belief",
    score: 85,
    domain: [0, 150],
  },
  {
    sub_cat: "Unique",
    score: 85,
    domain: [0, 150],
  },
  {
    sub_cat: "leadership",
    score: 79,
    domain: [0, 150],
  },
];

export default function RadarCharts() {
  return (
    <ResponsiveContainer width="100%" height={250}>
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <Tooltip />
        <PolarGrid />
        <PolarAngleAxis dataKey="sub_cat" />
        <PolarRadiusAxis domain={[0, 150]} angle={90} />
        <Radar
          dataKey="score"
          stroke="#3B82F6"
          fill="#3B82F6"
          fillOpacity={0.5}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}
