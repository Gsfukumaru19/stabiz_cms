import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function Section3({
  data,
  firstDataKey = "1_score",
  secondDataKey = "2_score",
  yDataKey = "name",
}) {
  return (
    // <ResponsiveContainer width="100%" height="400px">
    <BarChart
      width={700}
      height={700}
      data={data}
      layout="vertical"
      stackOffset="sign"
      margin={{ top: 5, bottom: 5, left: 100, right: 50 }}
    >
      <CartesianGrid strokeDasharray="3 3" />

      <XAxis type="number" />
      <YAxis type="category" dataKey={yDataKey} fontSize="12" />
      <Tooltip />
      <Legend style={{ marginTop: "10px" }} />
      <ReferenceLine x={0} stroke="#000" />
      <Bar dataKey={firstDataKey} fill="#3B82F6" stackId="stack" />
      <Bar dataKey={secondDataKey} fill="#F87CCC" stackId="stack" />
    </BarChart>
    // </ResponsiveContainer>
  );
}
