import cx from "clsx";
import React from "react";
import { useTranslation } from "react-i18next";

import styles from "./styles.module.css";

export function DiagnosisContainer({ sectionTitle, headerTitle, children }) {
  const { t } = useTranslation();

  return (
    <>
      <h1 className="tracking-[28px] text-white text-5xl">{t(headerTitle)}</h1>

      <div className="relative flex mt-16">
        {sectionTitle && (
          <p
            className={cx(
              styles.verticalText,
              "tracking-[10px] w-max text-white text-opacity-80 text-7xl"
            )}
          >
            {sectionTitle}
          </p>
        )}
        {children}
      </div>
    </>
  );
}
