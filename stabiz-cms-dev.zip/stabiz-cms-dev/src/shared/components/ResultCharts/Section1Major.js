import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ReferenceLine,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { getBarFillColor } from "./utils";

export default function Section1Major({ data, yKey, xKey }) {
  return (
    <BarChart
      width={500}
      height={300}
      data={data}
      layout="vertical"
      margin={{ top: 5, right: 10, left: 50, bottom: 5 }}
    >
      <XAxis type="number" />
      <YAxis yAxisId={0} type="category" dataKey={yKey} tickLine axisLine />
      <ReferenceLine x={0} stroke="#000" />
      {/* <Legend /> */}
      <CartesianGrid strokeDasharray="1 1" />
      <Tooltip />
      <Bar dataKey={xKey}>
        {data.map((d) => {
          return <Cell key={d[xKey]} fill={getBarFillColor(d[xKey])} />;
        })}
      </Bar>
    </BarChart>
  );
}
