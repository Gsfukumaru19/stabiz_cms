import "nprogress/nprogress.css";

import NProgress from "nprogress";
import { useEffect } from "react";

export default function TopProgressBar() {
  useEffect(() => {
    NProgress.configure({ showSpinner: false });
    NProgress.start();

    return () => {
      NProgress.done();
    };
  });

  return "";
}
